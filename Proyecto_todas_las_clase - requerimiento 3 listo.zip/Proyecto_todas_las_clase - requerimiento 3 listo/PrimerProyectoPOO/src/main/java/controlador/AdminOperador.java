/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import modelo.Cliente;


/**
 *
 * @author josue
 */

public class AdminOperador {
    private AdministradorEmpleado adminEmpleados= new AdministradorEmpleado();
    private ArrayList<Cliente> clientes= new ArrayList<Cliente>();
    private AdministradorVehiculos adminVehiculo=new AdministradorVehiculos();

    public AdminOperador() {
    }
    
    public boolean hacerLogin(String nombre,String clave){
        if(adminEmpleados.buscarEmpleado(nombre)==null){
            return adminEmpleados.comprobarClave(nombre, clave);
        }
        return false;
        
        
    }
    
    //metodo que no esta en el modelo
    public String agregarEmpleado(String correo, boolean admin){
        if(adminEmpleados.crearEmpleado(correo, admin)){
            return "Empleado agregado con exito";
        }else{
            return "Fallo en la creacion del empleado";
        }
    }
    
    public String buscarEmpleado(String nombre){
    
        return adminEmpleados.getEmpleado(nombre);
    }
    
    
    public Cliente buscarCliente(String cedula){
        
        for (int i = 0; i < clientes.size(); i++) {
            Cliente actCliente = clientes.get(i);
            if(actCliente.getCedula().equals(cedula)){
                return actCliente;
            }
            
        }
        return null;
    }

    @Override
    public String toString() {
        return "AdminOperador{" + "adminEmpleados=" + adminEmpleados + ", clientes=" + clientes + ", adminVehiculo=" + adminVehiculo + '}';
    }

    
    
    
}
