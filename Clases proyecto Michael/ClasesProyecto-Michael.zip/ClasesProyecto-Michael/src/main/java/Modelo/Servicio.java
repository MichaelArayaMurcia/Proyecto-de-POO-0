package Modelo;

import java.util.Calendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author h
 */


public class Servicio {
    String Id = "";
    Calendar fechaInicio = Calendar.getInstance();
    Calendar fechaFinal = Calendar.getInstance();
    Double montoPagado = 0.00;
    String actividadRealizada = "";
    String tipoServicio = "";
    String empresa = "";
    //Vehiculo vehiculo = new Vehiculo;

    public Servicio(String id, Double montoPagado, String actividadRealizada, String tipoServicio, String empresa) {
        Id = id;
        this.montoPagado = montoPagado;
        this.actividadRealizada = actividadRealizada;
        this.tipoServicio = tipoServicio;
        this.empresa = empresa;
    }

    @Override
    public String toString() {
        return "Servicio{" + "Id=" + Id + ", fechaInicio=" + fechaInicio + ", fechaFinal=" + fechaFinal + ", montoPagado=" + montoPagado + ", actividadRealizada=" + actividadRealizada + ", tipoServicio=" + tipoServicio + ", empresa=" + empresa + '}';
    }
    
    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public Calendar getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Calendar fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Calendar getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Calendar fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public Double getMontoPagado() {
        return montoPagado;
    }

    public void setMontoPagado(Double montoPagado) {
        this.montoPagado = montoPagado;
    }

    public String getActividadRealizada() {
        return actividadRealizada;
    }

    public void setActividadRealizada(String actividadRealizada) {
        this.actividadRealizada = actividadRealizada;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

}
