/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import Modelo.Empresa;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author h
 */
public class AdministradorEmpresas {
    ArrayList<Empresa> listaEmpresas; 

    public ArrayList<Empresa> getListaEmpresas() {
        return listaEmpresas;
    }

    public void setListaEmpresas(ArrayList<Empresa> listaEmpresas) {
        this.listaEmpresas = listaEmpresas;
    }
    
    public void agregarEmpresa(Empresa nuevaEmpresa){
        this.listaEmpresas.add(nuevaEmpresa);
    }
    
    public Empresa crearEmpresa(){
        System.out.println("Inserte la razonSocial");
        String razonSocial = "";
        Scanner objetoLector = new Scanner(System.in);
        razonSocial = objetoLector.nextLine();

        System.out.println("Inserte el numero cedula");
        String numeroCedula;
        numeroCedula = objetoLector.nextLine();

        System.out.println("Inserte el telefono");
        String telefono;
        telefono = objetoLector.nextLine();

        System.out.println("Inserte la direccion");
        String direccion;
        direccion = objetoLector.nextLine();
            
        Empresa nuevaEmpresa = new Empresa(razonSocial, numeroCedula, telefono, direccion);
        
        return nuevaEmpresa;
    }
    
        public void eliminarEmpresas(String cedula){
            for(int i = 0; i < listaEmpresas.size(); i++){
                 if(listaEmpresas.get(i).getNumeroCedula() == cedula){
                    listaEmpresas.remove(i);
                }
            }
        System.out.println("No se encontró ningún servicio");
    }
}
