/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;



/**
 *
 * @author araya
 */
public class Vehiculo {
    private String placa;
    private int annoFabricacion;
    private estilo Estilo;
    private String color;
    private String marca;
    private int capacidad;
    private double kilometraje;
    private int numeroPuertas;
    private String numeroVin;
    private double mpg;
    private String sucursal;
    private double costoAlquiler;
    private int capacidadMaletas;
    private transmision tipoTransmision;
    private estado estado;
    private String foto;

    public Vehiculo(String placa, int annoFabricacion, estilo Estilo, String color, String marca, int capacidad, double kilometraje, int numeroPuertas, String numeroVin, double mpg, String sucursal, double costoAlquiler, int capacidadMaletas, transmision tipoTransmision, String foto) {
        this.placa = placa;
        this.annoFabricacion = annoFabricacion;
        this.Estilo = Estilo;
        this.color = color;
        this.marca = marca;
        this.capacidad = capacidad;
        this.kilometraje = kilometraje;
        this.numeroPuertas = numeroPuertas;
        this.numeroVin = numeroVin;
        this.mpg = mpg;
        this.sucursal = sucursal;
        this.costoAlquiler = costoAlquiler;
        this.capacidadMaletas = capacidadMaletas;
        this.tipoTransmision = tipoTransmision;
        this.estado=estado.Activo;
        this.foto = foto;
    }

    public Vehiculo() {
    }

    public String getPlaca() {
        return placa;
    }

    public int getAnnoFabricacion() {
        return annoFabricacion;
    }

    public void setAnnoFabricacion(int annoFabricacion) {
        this.annoFabricacion = annoFabricacion;
    }

    public estilo getEstilo() {
        return Estilo;
    }

    public void setEstilo(estilo Estilo) {
        this.Estilo = Estilo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public double getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(double kilometraje) {
        this.kilometraje = kilometraje;
    }

    public int getNumeroPuertas() {
        return numeroPuertas;
    }

    public void setNumeroPuertas(int numeroPuertas) {
        this.numeroPuertas = numeroPuertas;
    }

    public String getNumeroVin() {
        return numeroVin;
    }

    public void setNumeroVin(String numeroVin) {
        this.numeroVin = numeroVin;
    }

    public double getMpg() {
        return mpg;
    }

    public void setMpg(double mpg) {
        this.mpg = mpg;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public double getCostoAlquiler() {
        return costoAlquiler;
    }

    public void setCostoAlquiler(double costoAlquiler) {
        this.costoAlquiler = costoAlquiler;
    }

    public int getCapacidadMaletas() {
        return capacidadMaletas;
    }

    public void setCapacidadMaletas(int capacidadMaletas) {
        this.capacidadMaletas = capacidadMaletas;
    }

    public transmision getTipoTransmision() {
        return tipoTransmision;
    }

    public void setTipoTransmision(transmision tipoTransmision) {
        this.tipoTransmision = tipoTransmision;
    }

    public estado getEstado() {
        return estado;
    }

    public void setEstado(estado estado) {
        this.estado = estado;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "placa=" + placa + ", annoFabricacion=" + annoFabricacion + ", Estilo=" + Estilo + ", color=" + color + ", marca=" + marca + ", capacidad=" + capacidad + ", kilometraje=" + kilometraje + ", numeroPuertas=" + numeroPuertas + ", mpg=" + mpg + ", sucursal=" + sucursal + ", capacidadMaletas=" + capacidadMaletas + ", tipoTransmision=" + tipoTransmision + ", estado=" + estado + '}';
    }
        
}
