/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.Vehiculo;
import modelo.estilo;
import modelo.transmision;
import modelo.estado;

/**
 *
 * @author araya
 */
public class AdministradorVehiculos {
    private ArrayList<Vehiculo> listaVehiculos = new ArrayList<Vehiculo>();

    public AdministradorVehiculos() {
    }
   
    
    public void registrarVehiculo(String placa, int annoFabricacion, estilo Estilo, String color, String marca, int capacidad, double kilometraje, int numeroPuertas, String numeroVin, double mpg, String sucursal, double costoAlquiler, int capacidadMaletas, transmision tipoTransmision, String foto){
        if(listaVehiculos.size()==0){
            Vehiculo nuevoVehiculo = new Vehiculo(placa, annoFabricacion, Estilo, color, marca, capacidad, kilometraje, numeroPuertas, numeroVin, mpg, sucursal, costoAlquiler, capacidadMaletas, tipoTransmision, foto);
            this.listaVehiculos.add(nuevoVehiculo);
        }
        else{
            boolean noExiste = true;
            for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca()==placa){
                System.out.println("El vehiculo ya existe en la lista.");
                noExiste = false;
                break;
            }
            }
            if(noExiste){
                Vehiculo nuevoVehiculo = new Vehiculo(placa, annoFabricacion, Estilo, color, marca, capacidad, kilometraje, numeroPuertas, numeroVin, mpg, sucursal, costoAlquiler, capacidadMaletas, tipoTransmision, foto);
                this.listaVehiculos.add(nuevoVehiculo);
            }
        }
    }
    
    public Vehiculo buscarVehiculo(String placa){
        for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca()==placa){
                return unVehiculo;
            }
        }
        return null;
    }
    
    public void cambiarEstadoVehiculo(){
        System.out.println("Ingrese la placa del carro al que desea cambiarle el estado: ");
        String placa;
        Scanner objetoLector = new Scanner(System.in);
        placa = objetoLector.nextLine();
        System.out.println("Ingrese el nuevo estado del Vehiculo: ");
        String Estado = objetoLector.nextLine();
        estado nuevoEstado = estado.Activo;
        if(Estado == estado.Mantenimiento.name()){
            nuevoEstado = estado.Mantenimiento;
        }
        else if(Estado == estado.Inactivo.name()){
            nuevoEstado = estado.Inactivo;
        }
        for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca()==placa){
                unVehiculo.setEstado(nuevoEstado);
            }
        }
    }
    public ArrayList listaCarros(){
        return listaVehiculos;
    }
    
    //public void cambiarPropiedadVehiculo(String placa){}
}
