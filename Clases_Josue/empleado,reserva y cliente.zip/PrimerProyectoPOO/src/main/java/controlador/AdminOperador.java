/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import modelo.Cliente;


/**
 *
 * @author josue
 */
public class AdminOperador {
    private AdministradorEmpleado adminEmpleados;
    private ArrayList<Cliente> clientes= new ArrayList<Cliente>();
    //private AdministradorVehiculos adminVehiculo;

    public AdminOperador() {
    }
    
    public boolean hacerLogin(String nombre,String clave){
        if(adminEmpleados.buscarEmpleado(nombre)!=null){
            return adminEmpleados.comprobarClave(nombre, clave);
        }
        return false;
        
        
    }
    
    public Cliente buscarCliente(String cedula){
        
        for (int i = 0; i < clientes.size(); i++) {
            Cliente actCliente = clientes.get(i);
            if(actCliente.getCedula().equals(cedula)){
                return actCliente;
            }
            
        }
        return null;
    }
}
