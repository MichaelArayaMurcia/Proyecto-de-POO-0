/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Calendar;

/**
 *
 * @author josue
 */
public class Licencia {
    private String numeroLicencia;
    private Calendar fechaEmision;
    private Calendar feachaExpiracion;
    private String tipoLicencia;
    private String imagenLicencia;

    public Licencia(String numeroLicencia, Calendar fechaEmision, Calendar feachaExpiracion, String tipoLicencia, String imagenLicencia) {
        this.numeroLicencia = numeroLicencia;
        this.fechaEmision = fechaEmision;
        this.feachaExpiracion = feachaExpiracion;
        this.tipoLicencia = tipoLicencia;
        this.imagenLicencia = imagenLicencia;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }

    public Calendar getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Calendar fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public Calendar getFeachaExpiracion() {
        return feachaExpiracion;
    }

    public void setFeachaExpiracion(Calendar feachaExpiracion) {
        this.feachaExpiracion = feachaExpiracion;
    }

    public String getTipoLicencia() {
        return tipoLicencia;
    }

    public void setTipoLicencia(String tipoLicencia) {
        this.tipoLicencia = tipoLicencia;
    }

    public String getImagenLicencia() {
        return imagenLicencia;
    }

    public void setImagenLicencia(String imagenLicencia) {
        this.imagenLicencia = imagenLicencia;
    }

    @Override
    public String toString() {
        return "Licencia{" + "numeroLicencia=" + numeroLicencia + ", fechaEmision=" + fechaEmision + ", feachaExpiracion=" + feachaExpiracion + ", tipoLicencia=" + tipoLicencia + ", imagenLicencia=" + imagenLicencia + '}';
    }
    
    
}
