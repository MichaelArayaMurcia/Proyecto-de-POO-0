/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author josue
 */
public enum ServiciosOpcionales {
    wifiIlimitado("Wifi Ilimitado",15),
    asistenciaCarretera("Asistencia Carretera",3.99),
    GPS("GPS",13.99),
    asientoNinos("Asientos para niño",6.99),
    coberturaDanos("Cobertura para daños",12.99),
    noservice("noservice", 0.0);
    
    private String name;
    private double precio;
    
    private ServiciosOpcionales(String name, double precio){
        this.name= name;
        this.precio=precio;
    }
    
    public String getName(){
        return name;
    }
    
    public double getPrecio(){
        return precio;
    }
}
