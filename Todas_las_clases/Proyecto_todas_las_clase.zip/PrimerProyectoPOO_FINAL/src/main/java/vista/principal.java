/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;
/**
 *
 * @author josue
 */
import modelo.ServiciosOpcionales;
import java.util.Random;
import modelo.repositorio;
import controlador.AdminOperador;

public class principal {
    
    public static void main(String[] args){
        //String comprobacion="hola@hotmail.com";
        //String name= comprobacion.substring(0, comprobacion.indexOf("@"));
        //Random  ran=new Random();
        //String lista="ABDC";
        //int numAlt=ran.nextInt(lista.length());
        //String carac= lista.substring(numAlt,numAlt+1);
        AdminOperador operador=new AdminOperador();/*
        String resul=operador.agregarEmpleado("josuebarrientossandoval@gmail.com", false);
        System.out.println(resul);
        System.out.println(operador.buscarEmpleado("josuebarrientos"));*/
    }
}
