/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;



/**
 *
 * @author araya
 */

import java.awt.Color;
import javax.swing.*;
public class Vehiculo {
    private String placa;
    private int annoFabricacion;
    private estilo Estilo;
    private String color;
    private String marca;
    private int capacidad;
    private double kilometraje;
    private int numeroPuertas;
    private String numeroVin;
    private double mpg;
    private String sucursal;
    private double costoAlquiler;
    private int capacidadMaletas;
    private transmision tipoTransmision;
    private estado estado;
    private String foto;
    private JPanel CuadroVehiculo;
    private JLabel VehiculoFoto;
    private JLabel VehiculoModeloPlaca;
    private JLabel VehiculoEstilo;
    private JLabel VehiculoTransmision;
    private JLabel VehiculoPasajeros;
    private JLabel VehiculoPrecio;
    private JButton SeleccionarVehiculo;
    private JButton MasInformacionVehiculo;

    public Vehiculo(String placa, int annoFabricacion, estilo Estilo, String color, String marca, int capacidad, double kilometraje, int numeroPuertas, String numeroVin, double mpg, String sucursal, double costoAlquiler, int capacidadMaletas, transmision tipoTransmision,String foto) {
        this.placa = placa;
        this.annoFabricacion = annoFabricacion;
        this.Estilo = Estilo;
        this.color = color;
        this.marca = marca;
        this.capacidad = capacidad;
        this.kilometraje = kilometraje;
        this.numeroPuertas = numeroPuertas;
        this.numeroVin = numeroVin;
        this.mpg = mpg;
        this.sucursal = sucursal;
        this.costoAlquiler = costoAlquiler;
        this.capacidadMaletas = capacidadMaletas;
        this.tipoTransmision = tipoTransmision;
        this.estado=estado.Activo;
        this.foto = foto;
        
        //----------------------------------------------------------------------
        
                CuadroVehiculo = new JPanel();
                CuadroVehiculo.setBackground(Color.LIGHT_GRAY);
                CuadroVehiculo.setLayout(null);
                
                VehiculoFoto = new JLabel(new ImageIcon(foto));
                VehiculoFoto.setBounds(5, 5, 90, 90);
                VehiculoModeloPlaca = new JLabel(this.marca + " - " + this.placa);
                VehiculoModeloPlaca.setBounds(100, 10, 400, 15);
                VehiculoEstilo = new JLabel(this.Estilo.name());
                VehiculoEstilo.setBounds(100, 30, 400, 15);
                VehiculoTransmision = new JLabel(this.tipoTransmision.name());
                VehiculoTransmision.setBounds(100, 50, 400, 15);
                VehiculoPasajeros = new JLabel("Capacidad de pasajeros:" + String.valueOf(this.capacidad));
                VehiculoPasajeros.setBounds(100, 70, 400, 15);
                VehiculoPrecio = new JLabel("$" + String.valueOf(this.costoAlquiler) + " por día");
                VehiculoPrecio.setBounds(335, 10, 100, 15);
                
                SeleccionarVehiculo = new JButton("Seleccionar Vehiculo");
                SeleccionarVehiculo.setBounds(315, 30, 180, 40);
        
                MasInformacionVehiculo = new JButton("Mas información...");
                MasInformacionVehiculo.setBounds(345, 75, 150, 20);
                
                CuadroVehiculo.add(VehiculoFoto);
                CuadroVehiculo.add(VehiculoModeloPlaca);
                CuadroVehiculo.add(VehiculoEstilo);
                CuadroVehiculo.add(VehiculoTransmision);
                CuadroVehiculo.add(VehiculoPasajeros);
                CuadroVehiculo.add(VehiculoPrecio);
                CuadroVehiculo.add(SeleccionarVehiculo);
                CuadroVehiculo.add(MasInformacionVehiculo);
    }

    public Vehiculo() {
    }

    public String getPlaca() {
        return placa;
    }

    public int getAnnoFabricacion() {
        return annoFabricacion;
    }

    public void setAnnoFabricacion(int annoFabricacion) {
        this.annoFabricacion = annoFabricacion;
    }

    public estilo getEstilo() {
        return Estilo;
    }

    public void setEstilo(estilo Estilo) {
        this.Estilo = Estilo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public double getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(double kilometraje) {
        this.kilometraje = kilometraje;
    }

    public int getNumeroPuertas() {
        return numeroPuertas;
    }

    public void setNumeroPuertas(int numeroPuertas) {
        this.numeroPuertas = numeroPuertas;
    }

    public String getNumeroVin() {
        return numeroVin;
    }

    public void setNumeroVin(String numeroVin) {
        this.numeroVin = numeroVin;
    }

    public double getMpg() {
        return mpg;
    }

    public void setMpg(double mpg) {
        this.mpg = mpg;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public double getCostoAlquiler() {
        return costoAlquiler;
    }

    public void setCostoAlquiler(double costoAlquiler) {
        this.costoAlquiler = costoAlquiler;
    }

    public int getCapacidadMaletas() {
        return capacidadMaletas;
    }

    public void setCapacidadMaletas(int capacidadMaletas) {
        this.capacidadMaletas = capacidadMaletas;
    }

    public transmision getTipoTransmision() {
        return tipoTransmision;
    }

    public void setTipoTransmision(transmision tipoTransmision) {
        this.tipoTransmision = tipoTransmision;
    }

    public estado getEstado() {
        return estado;
    }

    public void setEstado(estado estado) {
        this.estado = estado;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
    
    
    @Override
    public String toString() {
        return "Vehiculo{" + "placa=" + placa + ", annoFabricacion=" + annoFabricacion + ", Estilo=" + Estilo + ", color=" + color + ", marca=" + marca + ", capacidad=" + capacidad + ", kilometraje=" + kilometraje + ", numeroPuertas=" + numeroPuertas + ", numeroVin=" + numeroVin + ", mpg=" + mpg + ", sucursal=" + sucursal + ", costoAlquiler=" + costoAlquiler + ", capacidadMaletas=" + capacidadMaletas + ", tipoTransmision=" + tipoTransmision + ", estado=" + estado + ", foto=" + foto + ", VehiculoTransmision=" + VehiculoTransmision + ", VehiculoPasajeros=" + VehiculoPasajeros + ", VehiculoPrecio=" + VehiculoPrecio + ", SeleccionarVehiculo=" + SeleccionarVehiculo + ", MasInformacionVehiculo=" + MasInformacionVehiculo + '}';
    }

    

    public JPanel getCuadroVehiculo() {
        return CuadroVehiculo;
    }

    public JLabel getVehiculoFoto() {
        return VehiculoFoto;
    }

    public JLabel getVehiculoModeloPlaca() {
        return VehiculoModeloPlaca;
    }

    public JLabel getVehiculoEstilo() {
        return VehiculoEstilo;
    }

    public JLabel getVehiculoTransmision() {
        return VehiculoTransmision;
    }

    public JLabel getVehiculoPasajeros() {
        return VehiculoPasajeros;
    }

    public JLabel getVehiculoPrecio() {
        return VehiculoPrecio;
    }

    public JButton getSeleccionarVehiculo() {
        return SeleccionarVehiculo;
    }

    public JButton getMasInformacionVehiculo() {
        return MasInformacionVehiculo;
    }
        
    
}
