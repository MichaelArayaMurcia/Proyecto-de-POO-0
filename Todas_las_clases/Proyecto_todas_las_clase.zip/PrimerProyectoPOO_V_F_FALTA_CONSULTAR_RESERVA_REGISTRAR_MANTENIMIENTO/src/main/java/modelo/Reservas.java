/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Calendar;

/**
 *
 * @author josue
 */
public class Reservas {
    private int numReserva;
    private Cliente nombreCliente;
    private Vehiculo vehiculo;
    private String operador;
    private String sedeRecogida;
    private String sedeEntrega;
    private Calendar fechaInicio;
    private Calendar fechaFinal;
    private ServiciosOpcionales[] ServiciosExtra;
    private double precio;


    public Reservas(int numReserva, Cliente nombreCliente, Vehiculo vehiculo, String operador, String sedeRecogida, String sedeEntrega, 
                    Calendar fechaInicio, Calendar fechaFinal, ServiciosOpcionales[] ServiciosExtra, double precio) {
        this.numReserva = numReserva;
        this.nombreCliente = nombreCliente;
        this.vehiculo= vehiculo;
        this.operador = operador;
        this.sedeRecogida = sedeRecogida;
        this.sedeEntrega = sedeEntrega;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
        this.ServiciosExtra = ServiciosExtra;
        this.precio = precio;
    }
    

    public String getSedeRecogida() {
        return sedeRecogida;
    }

    public void setSedeRecogida(String sedeRecogida) {
        this.sedeRecogida = sedeRecogida;
    }

    public String getSedeEntrega() {
        return sedeEntrega;
    }

    public void setSedeEntrega(String sedeEntrega) {
        this.sedeEntrega = sedeEntrega;
    }

    public Calendar getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Calendar fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Calendar getFechaFinal() {
        return fechaFinal;
    }

      
    public void setFechaFinal(Calendar fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public int getNumReserva() {
        return numReserva;
    }

    public void setNumReserva(int numReserva) {
        this.numReserva = numReserva;
    }


    public String getOperador() {
        return operador;
    }

    public void setOperador(String operador) {
        this.operador = operador;
    }

    public ServiciosOpcionales[] getServiciosExtra() {
        return ServiciosExtra;
    }

    public void setServiciosExtra(ServiciosOpcionales[] ServiciosExtra) {
        this.ServiciosExtra = ServiciosExtra;
    }

    public Cliente getNombreCliente() {
        return nombreCliente;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    

    @Override
    public String toString() {
        return "Reservas{" + "numReserva=" + numReserva + ", nombreCliente=" + nombreCliente + ", vehiculo=" + vehiculo 
                + ", operador=" + operador + ", sedeRecogida=" + sedeRecogida + ", sedeEntrega=" + sedeEntrega 
                + ", fechaInicio=" + fechaInicio + ", fechaFinal=" + fechaFinal + ", ServiciosExtra=" + ServiciosExtra + ", precio=" + precio + '}';
    }
    
    
 
    
    
    
    
    
}
