/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

/**
 *
 * @author Aldokler
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import controlador.*;
import java.util.*;
import java.io.File;
import javax.swing.text.JTextComponent;
import modelo.*;
public class Main {
    static AdminOperador adminOperador = new AdminOperador();
    static AdministradorServicios administradorServicios = new AdministradorServicios();
    static AdministradorEmpresas administradorEmpresas = new AdministradorEmpresas();
    
    public static  String formatoFecha(Calendar fecha){
        return fecha.get(Calendar.DATE)+"/"+(fecha.get(Calendar.MONTH)+1)+"/"+fecha.get(Calendar.YEAR);
    }
    
    //clases que no estan en archivo final
    public static String obtenerEstilo(estilo est){
        switch (est) {
            case MiniVan -> {
                return "Mini Van";
            }
            case SUV -> {
                return "SUV";
            }
            case compacto -> {
                return "Compacto";
            }
            case convertible_economico -> {
                return "Convertible economico";
            }
            case intermedio -> {
                return "Intermedio";
            }
            case pickup -> {
                return "pickup";
            }
            default -> {
                return "no hay nada";
            }
        }
        
        
    }
    
    //clases que no estan en archivo final
    public static String obtenerTransmision(transmision trans){
       switch (trans){
           case automata ->{
               return "Automatico";
           }
           case manual ->{
               return "manual";
           }
           default ->{
               return "no se ha selecccionado";
           }
       }
   }
   
    public static void clearText(JTextComponent[] textos){
        for(JTextComponent x : textos)
            x.setText("");
    }
    
    private static void Window(){
        JFrame ventana = new JFrame("Rent a car A&B");
        /*
         *  #############################
         *  ########---Submenus---#######
         *  #############################
         */
        
        JPanel MenuPrincipal = new JPanel();
        MenuPrincipal.setBounds(0, 0, 1080, 720);
        MenuPrincipal.setBackground(Color.getHSBColor(167, 34, 81));
        MenuPrincipal.setLayout(null);
        MenuPrincipal.setVisible(true);
        
        JPanel MenuRegistrarCliente = new JPanel();
        MenuRegistrarCliente.setBounds(0, 0, 1080, 720);
        MenuRegistrarCliente.setBackground(Color.getHSBColor(167, 34, 81));
        MenuRegistrarCliente.setLayout(null);
        
        JPanel MenuAgregarVehiculo = new JPanel();
        MenuAgregarVehiculo.setBounds(0, 0, 1080, 720);
        MenuAgregarVehiculo.setBackground(Color.getHSBColor(167, 34, 81));
        MenuAgregarVehiculo.setLayout(null);
        
        JPanel MenuRegistrarEmpresa = new JPanel();
        MenuRegistrarEmpresa.setBounds(0, 0, 1080, 720);
        MenuRegistrarEmpresa.setBackground(Color.getHSBColor(167, 34, 81));
        MenuRegistrarEmpresa.setLayout(null);
         
        JPanel MenuRegistrarMantenimiento = new JPanel();
        MenuRegistrarMantenimiento.setBounds(0, 0, 1080, 720);
        MenuRegistrarMantenimiento.setBackground(Color.getHSBColor(167, 34, 81));
        MenuRegistrarMantenimiento.setLayout(null);
        
        JPanel MenuEditarVehiculo = new JPanel();
        MenuEditarVehiculo.setBounds(0, 0, 1080, 720);
        MenuEditarVehiculo.setBackground(Color.getHSBColor(167, 34, 81));
        MenuEditarVehiculo.setLayout(null);
        
        JPanel MenuHacerReserva = new JPanel();
        MenuHacerReserva.setBounds(0, 0, 1080, 720);
        MenuHacerReserva.setBackground(Color.getHSBColor(167, 34, 81));
        MenuHacerReserva.setLayout(null);
        
        JPanel MenuConsultarReserva = new JPanel();
        MenuConsultarReserva.setBounds(0, 0, 1080, 720);
        MenuConsultarReserva.setBackground(Color.getHSBColor(167, 34, 81));
        MenuConsultarReserva.setLayout(null);
        
        JPanel MenuRegistrarAdmin = new JPanel();
        MenuRegistrarAdmin.setBounds(0, 0, 1080, 720);
        MenuRegistrarAdmin.setBackground(Color.getHSBColor(167, 34, 81));
        MenuRegistrarAdmin.setLayout(null);
        
        /*
         *  #######################################################
         *  ###########---Componentes MenuPrincipal---#############
         *  #######################################################
         */
        
        ImageIcon LogoImage = new ImageIcon("images/Rent_a_Car_Logo.png");
        JLabel LogoPanel = new JLabel(LogoImage);
        LogoPanel.setBounds(140, 100, 800, 400);
        
        JButton botonRegistrarCliente = new JButton("Registrar cliente");
        botonRegistrarCliente.setBounds(20, 530, 245, 50);
        botonRegistrarCliente.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuRegistrarCliente);
            MenuRegistrarCliente.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonAgregarVehiculo = new JButton("Agregar vehículo");
        botonAgregarVehiculo.setBounds(285, 530, 245, 50);
        botonAgregarVehiculo.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuAgregarVehiculo);
            MenuAgregarVehiculo.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonRegistrarEmpresa = new JButton("Registrar empresa");
        botonRegistrarEmpresa.setBounds(550, 530, 245, 50);
        botonRegistrarEmpresa.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuRegistrarEmpresa);
            MenuRegistrarEmpresa.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonRegistrarMantenimiento = new JButton("Registrar servicio de mantenimiento");
        botonRegistrarMantenimiento.setBounds(815, 530, 245, 50);
        botonRegistrarMantenimiento.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuRegistrarMantenimiento);
            MenuRegistrarMantenimiento.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonEditarVehiculo = new JButton("Editar vehiculo");
        botonEditarVehiculo.setBounds(20, 600, 245, 50);
        botonEditarVehiculo.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuEditarVehiculo);
            MenuEditarVehiculo.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonHacerReserva = new JButton("Hacer una reserva");
        botonHacerReserva.setBounds(285, 600, 245, 50);
        botonHacerReserva.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuHacerReserva);
            MenuHacerReserva.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonConsultarReserva = new JButton("Consultar una reserva");
        botonConsultarReserva.setBounds(550, 600, 245, 50);
        botonConsultarReserva.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuConsultarReserva);
            MenuConsultarReserva.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        JButton botonRegistrarAdmin = new JButton("Registrar usuario 'Servicio al cliente'");
        botonRegistrarAdmin.setBounds(815, 600, 245, 50);
        botonRegistrarAdmin.addActionListener((ActionEvent e) -> {
            MenuPrincipal.setVisible(false);
            ventana.add(MenuRegistrarAdmin);
            MenuRegistrarAdmin.setVisible(true);
            ventana.remove(MenuPrincipal);
        });
        
        MenuPrincipal.add(LogoPanel);
        MenuPrincipal.add(botonRegistrarCliente);
        MenuPrincipal.add(botonAgregarVehiculo);
        MenuPrincipal.add(botonRegistrarEmpresa);
        MenuPrincipal.add(botonRegistrarMantenimiento);
        MenuPrincipal.add(botonEditarVehiculo);
        MenuPrincipal.add(botonHacerReserva);
        MenuPrincipal.add(botonConsultarReserva);
        MenuPrincipal.add(botonRegistrarAdmin);
        
        /*  
         *  ##############################################################
         *  ###########---Componentes MenuRegistrarCliente---#############
         *  ##############################################################
         */
        
        JPanel CuadroRegistrarCliente = new JPanel();
        CuadroRegistrarCliente.setBounds(290, 110, 500, 500);
        float[] celestico = Color.RGBtoHSB(107, 255, 208, null);
        CuadroRegistrarCliente.setBackground(Color.getHSBColor(celestico[0], celestico[1], celestico[2]));
        CuadroRegistrarCliente.setLayout(null);
        
        MenuRegistrarCliente.add(CuadroRegistrarCliente);
        
        JLabel TitleRegistrarCliente = new JLabel("Registrar Cliente");
        TitleRegistrarCliente.setBounds(190, 5, 500, 20);
        
        JLabel LabelClienteNombre = new JLabel("Nombre Completo");
        LabelClienteNombre.setBounds(5, 50, 400, 15);
        JTextField TextClienteNombre = new JTextField();
        TextClienteNombre.setBounds(150, 50, 330, 16);
        
        JLabel LabelClienteCedula = new JLabel("Cédula");
        LabelClienteCedula.setBounds(5, 70, 400, 15);
        JTextField TextClienteCedula = new JTextField();
        TextClienteCedula.setBounds(150, 70, 330, 16);
        
        JLabel LabelClienteEmail = new JLabel("Correo electrónico");
        LabelClienteEmail.setBounds(5, 90, 400, 15);
        JTextField TextClienteEmail = new JTextField();
        TextClienteEmail.setBounds(150, 90, 330, 16);
        
        JLabel LabelClienteTelefono = new JLabel("Número de teléfono");
        LabelClienteTelefono.setBounds(5, 110, 400, 15);
        JTextField TextClienteTelefono = new JTextField();
        TextClienteTelefono.setBounds(150, 110, 330, 16);
        
        JLabel LabelClienteDireccion = new JLabel("Dirección exacta");
        LabelClienteDireccion.setBounds(5, 130, 400, 15);
        JTextArea TextClienteDireccion = new JTextArea();
        TextClienteDireccion.setBounds(150, 130, 330, 96);
        
        JLabel LabelClienteNumeroLic = new JLabel("Número de licencia");
        LabelClienteNumeroLic.setBounds(5, 230, 400, 15);
        JTextField TextClienteNumeroLic = new JTextField();
        TextClienteNumeroLic.setBounds(150, 230, 330, 16);
        
        JLabel LabelClienteType = new JLabel("Tipo de licencia");
        LabelClienteType.setBounds(5, 250, 400, 15);
        JTextField TextClienteType = new JTextField();
        TextClienteType.setBounds(150, 250, 330, 16);
        
        String Dia[]={"1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                    "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                    "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};
        
        String Mes[]={"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                      "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
        
        String AnoCreacion[]={"2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020"};
        
        String AnoExpiracion[]={"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"};
        
        JLabel LabelClienteEmisión = new JLabel("Fecha de emisión de la licencia                     de                                     del");
        LabelClienteEmisión.setBounds(5, 270, 400, 15);
        JComboBox TextClienteEmisiónDia = new JComboBox(Dia);
        TextClienteEmisiónDia.setBounds(200, 270, 40, 16);
        JComboBox TextClienteEmisiónMes = new JComboBox(Mes);
        TextClienteEmisiónMes.setBounds(265, 270, 100, 16);
        JComboBox TextClienteEmisiónAno = new JComboBox(AnoCreacion);
        TextClienteEmisiónAno.setBounds(390, 270, 60, 16);
        
        JLabel LabelClienteExpiración = new JLabel("Fecha de expiración de la licencia                de                                     del");
        LabelClienteExpiración.setBounds(5, 290, 400, 15);
        JComboBox TextClienteExpiracionDia = new JComboBox(Dia);
        TextClienteExpiracionDia.setBounds(200, 290, 40, 16);
        JComboBox TextClienteExpiracionMes = new JComboBox(Mes);
        TextClienteExpiracionMes.setBounds(265, 290, 100, 16);
        JComboBox TextClienteExpiracionAno = new JComboBox(AnoExpiracion);
        TextClienteExpiracionAno.setBounds(390, 290, 60, 16);
        
        JLabel LabelClienteFoto = new JLabel("Fotografía de la licencia");
        LabelClienteFoto.setBounds(5, 310, 400, 15);
        JButton BuscarClienteFoto = new JButton("Buscar...");
        BuscarClienteFoto.setBounds(380, 310, 100, 15);
        JTextField RutaClienteFoto = new JTextField();
        RutaClienteFoto.setBounds(150, 310, 220, 15);
        String[] FotoDir = new String[1];
        JLabel ImagenClienteFoto = new JLabel(new ImageIcon(""));
        ImagenClienteFoto.setBounds(150, 330, 200, 150);
        //linea que hay que agregar
        
        JTextComponent[] textosAgregarCliente = {TextClienteNombre, TextClienteCedula, TextClienteEmail, TextClienteTelefono,
                                                        TextClienteDireccion, TextClienteNumeroLic, TextClienteType};
        
        BuscarClienteFoto.addActionListener((ActionEvent f) ->{
            JFileChooser BuscarFoto = new JFileChooser();
            int returnValue = BuscarFoto.showOpenDialog(null);
            if(returnValue == JFileChooser.APPROVE_OPTION){
            File Foto = BuscarFoto.getSelectedFile();
            final String temp = Foto.getPath();
            FotoDir[0]=temp;
            RutaClienteFoto.setText(temp);
            ImagenClienteFoto.setIcon(new ImageIcon(Foto.getPath()));
            }
        });
        RutaClienteFoto.setEditable(false);
        
        JButton BotonRegistrarCliente = new JButton("Registrar");
        BotonRegistrarCliente.setBounds(395, 480, 100, 15);
        BotonRegistrarCliente.addActionListener((ActionEvent e) -> {
            if(!"".equals(TextClienteNombre.getText())&&!"".equals(TextClienteCedula.getText())&&
               !"".equals(TextClienteEmail.getText())&&!"".equals(TextClienteTelefono.getText())&&
               !"".equals(TextClienteDireccion.getText())&&!"".equals(TextClienteNumeroLic.getText())&&
               !"".equals(TextClienteType.getText())){
                Calendar emi=Calendar.getInstance();
                Calendar exp=Calendar.getInstance();
                emi.set(Calendar.DATE, Integer.parseInt((String) TextClienteEmisiónDia.getSelectedItem()));
                emi.set(Calendar.MONTH, TextClienteEmisiónMes.getSelectedIndex());
                emi.set(Calendar.YEAR, Integer.parseInt((String) TextClienteEmisiónAno.getSelectedItem()));
                exp.set(Calendar.DATE, Integer.parseInt((String) TextClienteExpiracionDia.getSelectedItem()));
                exp.set(Calendar.MONTH, TextClienteExpiracionMes.getSelectedIndex());
                exp.set(Calendar.YEAR, Integer.parseInt((String) TextClienteExpiracionAno.getSelectedItem()));
                
                boolean agregado=adminOperador.agregarCliente(TextClienteNombre.getText(), TextClienteCedula.getText(), 
                                                        TextClienteDireccion.getText(),TextClienteEmail.getText(), 
                                                        TextClienteTelefono.getText(), ImagenClienteFoto.getIcon().toString(), 
                                                        TextClienteNumeroLic.getText(), emi, exp, 
                                                        TextClienteType.getText(), FotoDir[0]);
                if(agregado){
                    JOptionPane.showMessageDialog(null, "Se ha agregado el cliente", "Informativo", JOptionPane.INFORMATION_MESSAGE);
                    clearText(textosAgregarCliente);
                    ImagenClienteFoto.setIcon(new ImageIcon(""));
                    MenuRegistrarCliente.setVisible(false);
                    ventana.add(MenuPrincipal);
                    MenuPrincipal.setVisible(true);
                    ventana.remove(MenuRegistrarCliente);
                }else{
                    JOptionPane.showMessageDialog(null, "Cliente existente", "Informativo", JOptionPane.INFORMATION_MESSAGE);
                }
            }else{
                System.out.println(adminOperador.getCliente(TextClienteCedula.getText()));
                JOptionPane.showMessageDialog(null, "Error", "Advertencia", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton VolverRegistrarCliente = new JButton("Volver");
        VolverRegistrarCliente.setBounds(5, 480, 100, 15);
        VolverRegistrarCliente.addActionListener((ActionEvent e) -> {
            clearText(textosAgregarCliente);
            ImagenClienteFoto.setIcon(new ImageIcon(""));
            MenuRegistrarCliente.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuRegistrarCliente);
        });
        
        //----------------------------------------------------------------------
        
        CuadroRegistrarCliente.add(TitleRegistrarCliente);
        CuadroRegistrarCliente.add(VolverRegistrarCliente);
        CuadroRegistrarCliente.add(BotonRegistrarCliente);
        CuadroRegistrarCliente.add(LabelClienteNombre);
        CuadroRegistrarCliente.add(TextClienteNombre);
        CuadroRegistrarCliente.add(LabelClienteCedula);
        CuadroRegistrarCliente.add(TextClienteCedula);
        CuadroRegistrarCliente.add(LabelClienteDireccion);
        CuadroRegistrarCliente.add(TextClienteDireccion);
        CuadroRegistrarCliente.add(LabelClienteEmail);
        CuadroRegistrarCliente.add(TextClienteEmail);
        CuadroRegistrarCliente.add(LabelClienteTelefono);
        CuadroRegistrarCliente.add(TextClienteTelefono);
        CuadroRegistrarCliente.add(LabelClienteFoto);
        CuadroRegistrarCliente.add(BuscarClienteFoto);
        CuadroRegistrarCliente.add(RutaClienteFoto);
        CuadroRegistrarCliente.add(LabelClienteNumeroLic);
        CuadroRegistrarCliente.add(TextClienteNumeroLic);
        CuadroRegistrarCliente.add(LabelClienteType);
        CuadroRegistrarCliente.add(TextClienteType);
        CuadroRegistrarCliente.add(LabelClienteEmisión);
        CuadroRegistrarCliente.add(TextClienteEmisiónDia);
        CuadroRegistrarCliente.add(TextClienteEmisiónMes);
        CuadroRegistrarCliente.add(TextClienteEmisiónAno);
        CuadroRegistrarCliente.add(LabelClienteExpiración);
        CuadroRegistrarCliente.add(TextClienteExpiracionDia);
        CuadroRegistrarCliente.add(TextClienteExpiracionMes);
        CuadroRegistrarCliente.add(TextClienteExpiracionAno);
        CuadroRegistrarCliente.add(ImagenClienteFoto);
        
        /*
         *  ###############################################################
         *  ###########---Componentes MenuAgregarVehiculo---###############
         *  ###############################################################
         */
        
        JPanel CuadroAgregarVehiculo = new JPanel();
        CuadroAgregarVehiculo.setBounds(190, 110, 700, 500);
        float[] unColor = Color.RGBtoHSB(107, 208, 255, null);
        CuadroAgregarVehiculo.setBackground(Color.getHSBColor(unColor[0], unColor[1], unColor[2]));
        CuadroAgregarVehiculo.setLayout(null);
        
        String estilo[] = {"Compacto", "Pickup", "Intermedio",
                           "SUV", "Mini-van", "Convertible económico"};
        
        String transmisión[] = {"Automático", "Manual"};
        
        JLabel TitleAgregarVehiculo = new JLabel("Agregar Vehículo");
        TitleAgregarVehiculo.setBounds(300, 5, 500, 20);
        
        JLabel LabelVehiculoPlaca = new JLabel("Placa");
        LabelVehiculoPlaca.setBounds(5, 50, 400, 15);
        JTextField TextVehiculoPlaca = new JTextField();
        TextVehiculoPlaca.setBounds(150, 50, 150, 16);
        
        JLabel LabelVehiculoMarca = new JLabel("Marca");
        LabelVehiculoMarca.setBounds(355, 50, 400, 15);
        JTextField TextVehiculoMarca = new JTextField();
        TextVehiculoMarca.setBounds(500, 50, 150, 16);
        
        JLabel LabelVehiculoEstilo = new JLabel("Estilo");
        LabelVehiculoEstilo.setBounds(5, 70, 400, 15);
        JComboBox TextVehiculoEstilo = new JComboBox(estilo);
        TextVehiculoEstilo.setBounds(150, 70, 150, 16);
        
        JLabel LabelVehiculoSucursal = new JLabel("Sucursal");
        LabelVehiculoSucursal.setBounds(355, 70, 400, 15);
        JTextField TextVehiculoSucursal = new JTextField();
        TextVehiculoSucursal.setBounds(500, 70, 150, 16);
        
        JLabel LabelVehiculoColor = new JLabel("Color");
        LabelVehiculoColor.setBounds(5, 90, 400, 15);
        JTextField TextVehiculoColor = new JTextField();
        TextVehiculoColor.setBounds(150, 90, 150, 16);
        
        JLabel LabelVehiculoCapacidad = new JLabel("Capacidad");
        LabelVehiculoCapacidad.setBounds(355, 90, 400, 15);
        JTextField TextVehiculoCapacidad = new JTextField();
        TextVehiculoCapacidad.setBounds(500, 90, 150, 16);
        
        JLabel LabelVehiculoPuertas = new JLabel("Numero de puertas");
        LabelVehiculoPuertas.setBounds(5, 110, 400, 15);
        JTextField TextVehiculoPuertas = new JTextField();
        TextVehiculoPuertas.setBounds(150, 110, 150, 16);
        
        JLabel LabelVehiculoMaletas = new JLabel("Capacidad de maletas");
        LabelVehiculoMaletas.setBounds(355, 110, 400, 15);
        JTextField TextVehiculoMaletas = new JTextField();
        TextVehiculoMaletas.setBounds(500, 110, 150, 16);
        
        JLabel LabelVehiculoFabricacion = new JLabel("Año de fabricación");
        LabelVehiculoFabricacion.setBounds(5, 130, 400, 15);
        JTextField TextVehiculoFabricacion = new JTextField();
        TextVehiculoFabricacion.setBounds(150, 130, 150, 16);
        
        JLabel LabelVehiculoVIN = new JLabel("Numero de Chasis"); //NumeroVin
        LabelVehiculoVIN.setBounds(355, 130, 400, 15);
        JTextField TextVehiculoVIN = new JTextField();
        TextVehiculoVIN.setBounds(500, 130, 150, 16);
        
        JLabel LabelVehiculoTransmision = new JLabel("Transmisión");
        LabelVehiculoTransmision.setBounds(5, 150, 400, 15);
        JComboBox TextVehiculoTransmision = new JComboBox(transmisión);
        TextVehiculoTransmision.setBounds(150, 150, 150, 16);
        
        JLabel LabelVehiculoKilometraje = new JLabel("Kilometraje");
        LabelVehiculoKilometraje.setBounds(355, 150, 400, 15);
        JTextField TextVehiculoKilometraje = new JTextField();
        TextVehiculoKilometraje.setBounds(500, 150, 150, 16);
        
        JLabel LabelVehiculoAlquiler = new JLabel("Costo de Alquiler");
        LabelVehiculoAlquiler.setBounds(5, 170, 400, 15);
        JTextField TextVehiculoAlquiler = new JTextField();
        TextVehiculoAlquiler.setBounds(150, 170, 150, 16);
        
        JLabel LabelVehiculoMPG = new JLabel("MPG (Millas por Galón)");
        LabelVehiculoMPG.setBounds(355, 170, 400, 15);
        JTextField TextVehiculoMPG = new JTextField();
        TextVehiculoMPG.setBounds(500, 170, 150, 16);
        
        JTextComponent[] textosAgregarVehiculo = {TextVehiculoPlaca, TextVehiculoMarca, TextVehiculoSucursal, TextVehiculoColor,
                                                 TextVehiculoCapacidad, TextVehiculoPuertas, TextVehiculoMaletas, TextVehiculoFabricacion,
                                                 TextVehiculoVIN, TextVehiculoKilometraje, TextVehiculoAlquiler, TextVehiculoMPG};
        
        JLabel LabelVehiculoFoto = new JLabel("Fotografía del vehículo");
        LabelVehiculoFoto.setBounds(5, 190, 400, 15);
        JButton BuscarVehiculoFoto = new JButton("Buscar...");
        BuscarVehiculoFoto.setBounds(500, 190, 100, 15);
        JTextField RutaVehiculoFoto = new JTextField();
        RutaVehiculoFoto.setBounds(150, 190, 330, 16);
        JLabel ImagenVehiculoFoto = new JLabel(new ImageIcon(""));
        ImagenVehiculoFoto.setBounds(100, 200, 500, 290);
        //linea que hay que agregar
        BuscarVehiculoFoto.addActionListener((ActionEvent f) ->{
            JFileChooser BuscarFoto = new JFileChooser();
            int returnValue = BuscarFoto.showOpenDialog(null);
            if(returnValue == JFileChooser.APPROVE_OPTION){
            File Foto = BuscarFoto.getSelectedFile();
            final String temp = Foto.getPath();
            FotoDir[0]=temp;
            RutaVehiculoFoto.setText(temp);
            ImagenVehiculoFoto.setIcon(new ImageIcon(Foto.getPath()));
            }
        });
        RutaVehiculoFoto.setEditable(false);
        
        JButton BotonAgregarVehiculo = new JButton("Agregar");
        BotonAgregarVehiculo.setBounds(595, 480, 100, 15);
        BotonAgregarVehiculo.addActionListener((ActionEvent e) -> {
            if(adminOperador.getAdminVehiculo().buscarVehiculo(TextVehiculoPlaca.getText()) == null){
                estilo EstiloVehiculo;
                if(TextVehiculoEstilo.getItemAt(TextVehiculoEstilo.getSelectedIndex()).toString() == "MiniVan"){
                    EstiloVehiculo = modelo.estilo.MiniVan;
                }else if(TextVehiculoEstilo.getItemAt(TextVehiculoEstilo.getSelectedIndex()).toString() == "compacto"){
                    EstiloVehiculo = modelo.estilo.compacto;
                }else if(TextVehiculoEstilo.getItemAt(TextVehiculoEstilo.getSelectedIndex()).toString() == "SUV"){
                    EstiloVehiculo = modelo.estilo.SUV;
                }else if(TextVehiculoEstilo.getItemAt(TextVehiculoEstilo.getSelectedIndex()).toString() == "intermedio"){
                    EstiloVehiculo = modelo.estilo.intermedio;
                }else if(TextVehiculoEstilo.getItemAt(TextVehiculoEstilo.getSelectedIndex()).toString() == "pickup"){
                    EstiloVehiculo = modelo.estilo.pickup;
                }else{
                    EstiloVehiculo = modelo.estilo.convertible_economico;
                }
                transmision TipoTransmision;
                if(TextVehiculoTransmision.getItemAt(TextVehiculoTransmision.getSelectedIndex()).toString() == "Manual"){
                    TipoTransmision = transmision.manual;
                }else{
                    TipoTransmision = transmision.automata;
                }
            adminOperador.getAdminVehiculo().registrarVehiculo(TextVehiculoPlaca.getText(), Integer.parseInt(TextVehiculoFabricacion.getText()),
                    EstiloVehiculo, TextVehiculoColor.getText(), TextVehiculoMarca.getText(), 
                    Integer.parseInt(TextVehiculoCapacidad.getText()), Double.parseDouble(TextVehiculoKilometraje.getText()), 
                    Integer.parseInt(TextVehiculoPuertas.getText()), TextVehiculoVIN.getText(), 
                    Double.parseDouble(TextVehiculoKilometraje.getText()), TextVehiculoSucursal.getText(), 
                    Double.parseDouble(TextVehiculoKilometraje.getText()), Integer.parseInt(TextVehiculoMaletas.getText()), 
                    TipoTransmision, FotoDir[0]);
            JOptionPane.showMessageDialog(ventana,"El vehiculo ha sido registrado con éxito.",":)",JOptionPane.INFORMATION_MESSAGE);
            clearText(textosAgregarVehiculo);
            ImagenVehiculoFoto.setIcon(new ImageIcon(""));
            MenuAgregarVehiculo.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuAgregarVehiculo);
            }else{
                JFrame f;  
                f=new JFrame();  
                JOptionPane.showMessageDialog(f,"El vehiculo ya ha sido registrado.","Alert",JOptionPane.WARNING_MESSAGE);}    
            
        });
        
        JButton VolverAgregarVehiculo = new JButton("Volver");
        VolverAgregarVehiculo.setBounds(5, 480, 100, 15);
        VolverAgregarVehiculo.addActionListener((ActionEvent e) -> {
            clearText(textosAgregarVehiculo);
            ImagenVehiculoFoto.setIcon(new ImageIcon(""));
            MenuAgregarVehiculo.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuAgregarVehiculo);
        });
        
        //---------------------------------------------------------------------
        
        CuadroAgregarVehiculo.add(TitleAgregarVehiculo);
        CuadroAgregarVehiculo.add(LabelVehiculoPlaca);
        CuadroAgregarVehiculo.add(TextVehiculoPlaca);
        CuadroAgregarVehiculo.add(LabelVehiculoMarca);
        CuadroAgregarVehiculo.add(TextVehiculoMarca);
        CuadroAgregarVehiculo.add(LabelVehiculoFabricacion);
        CuadroAgregarVehiculo.add(TextVehiculoFabricacion);
        CuadroAgregarVehiculo.add(LabelVehiculoEstilo);
        CuadroAgregarVehiculo.add(TextVehiculoEstilo);
        CuadroAgregarVehiculo.add(LabelVehiculoColor);
        CuadroAgregarVehiculo.add(TextVehiculoColor);
        CuadroAgregarVehiculo.add(LabelVehiculoCapacidad);
        CuadroAgregarVehiculo.add(TextVehiculoCapacidad);
        CuadroAgregarVehiculo.add(LabelVehiculoKilometraje);
        CuadroAgregarVehiculo.add(TextVehiculoKilometraje);
        CuadroAgregarVehiculo.add(LabelVehiculoPuertas);
        CuadroAgregarVehiculo.add(TextVehiculoPuertas);
        CuadroAgregarVehiculo.add(LabelVehiculoVIN);
        CuadroAgregarVehiculo.add(TextVehiculoVIN);
        CuadroAgregarVehiculo.add(LabelVehiculoMPG);
        CuadroAgregarVehiculo.add(TextVehiculoMPG);
        CuadroAgregarVehiculo.add(LabelVehiculoSucursal);
        CuadroAgregarVehiculo.add(TextVehiculoSucursal);
        CuadroAgregarVehiculo.add(LabelVehiculoAlquiler);
        CuadroAgregarVehiculo.add(TextVehiculoAlquiler);
        CuadroAgregarVehiculo.add(LabelVehiculoMaletas);
        CuadroAgregarVehiculo.add(TextVehiculoMaletas);
        CuadroAgregarVehiculo.add(LabelVehiculoTransmision);
        CuadroAgregarVehiculo.add(TextVehiculoTransmision);
        CuadroAgregarVehiculo.add(LabelVehiculoFoto);
        CuadroAgregarVehiculo.add(BuscarVehiculoFoto);
        CuadroAgregarVehiculo.add(RutaVehiculoFoto);
        CuadroAgregarVehiculo.add(VolverAgregarVehiculo);
        CuadroAgregarVehiculo.add(BotonAgregarVehiculo);
        CuadroAgregarVehiculo.add(ImagenVehiculoFoto);
        
        MenuAgregarVehiculo.add(CuadroAgregarVehiculo);
        
        /*  
         *  ##############################################################
         *  ###########---Componentes MenuRegistrarEmpresa---#############
         *  ##############################################################
         */
        
        JPanel CuadroRegistrarEmpresa = new JPanel();
        CuadroRegistrarEmpresa.setBounds(340, 160, 400, 400);
        float[] empresarial = Color.RGBtoHSB(107, 154, 255, null);
        CuadroRegistrarEmpresa.setBackground(Color.getHSBColor(empresarial[0], empresarial[1], empresarial[2]));
        CuadroRegistrarEmpresa.setLayout(null);
        
        MenuRegistrarEmpresa.add(CuadroRegistrarEmpresa);
        
        String provincias[] = {"San José", "Alajuela", "Cartago", "Heredia", "Guanacaste", "Puntarenas", "Limón"};
        
        JLabel TitleRegistrarEmpresa = new JLabel("Registrar Empresa");
        TitleRegistrarEmpresa.setBounds(150, 5, 500, 20);
        JButton VolverRegistrarEmpresa = new JButton("Volver");
        VolverRegistrarEmpresa.setBounds(5, 380, 100, 15);
        VolverRegistrarEmpresa.addActionListener((ActionEvent e) -> {
            MenuRegistrarEmpresa.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuRegistrarEmpresa);
        });
        
        JLabel LabelEmpresaName = new JLabel("Nombre de la empresa");
        LabelEmpresaName.setBounds(5, 50, 400, 15);
        JTextField TextEmpresaName = new JTextField();
        TextEmpresaName.setBounds(150, 50, 230, 16);
        
        JLabel LabelEmpresaRazon = new JLabel("Razón Social");
        LabelEmpresaRazon.setBounds(5, 70, 400, 15);
        JTextField TextEmpresaRazon = new JTextField();
        TextEmpresaRazon.setBounds(150, 70, 230, 16);
        
        JLabel LabelEmpresaCedula = new JLabel("Cédula Jurídica");
        LabelEmpresaCedula.setBounds(5, 90, 400, 15);
        JTextField TextEmpresaCedula = new JTextField();
        TextEmpresaCedula.setBounds(150, 90, 230, 16);
        
        JLabel LabelEmpresaTelefono = new JLabel("Telefono");
        LabelEmpresaTelefono.setBounds(5, 110, 400, 15);
        JTextField TextEmpresaTelefono = new JTextField();
        TextEmpresaTelefono.setBounds(150, 110, 230, 16);
        
        JLabel LabelEmpresaDireccion = new JLabel("Dirección");
        LabelEmpresaDireccion.setBounds(150, 135, 400, 15);
        
        JLabel LabelEmpresaProvincia = new JLabel("Provincia");
        LabelEmpresaProvincia.setBounds(25, 160, 400, 15);
        JComboBox TextEmpresaProvincia = new JComboBox(provincias);
        TextEmpresaProvincia.setBounds(5, 180, 100, 16); 
        
        JLabel LabelEmpresaCanton = new JLabel("Cantón");
        LabelEmpresaCanton.setBounds(155, 160, 400, 15);
        JTextField TextEmpresaCanton = new JTextField();
        TextEmpresaCanton.setBounds(110, 180, 130, 16);
        
        JLabel LabelEmpresaDistrito = new JLabel("Distrito");
        LabelEmpresaDistrito.setBounds(290, 160, 400, 15);
        JTextField TextEmpresaDistrito = new JTextField();
        TextEmpresaDistrito.setBounds(250, 180, 130, 16);
        
        JLabel LabelEmpresaSenal = new JLabel("Señas");
        LabelEmpresaSenal.setBounds(5, 210, 400, 15);
        JTextArea TextEmpresaSenal = new JTextArea();
        TextEmpresaSenal.setBounds(60, 210, 300, 112);
        
        JTextField ComponentesRegistrarEmpresa[] = {TextEmpresaName, TextEmpresaCedula, TextEmpresaTelefono, TextEmpresaCanton,
                                                    TextEmpresaDistrito, TextEmpresaRazon};
        int ComponentesRegistrarEmpresaSize = ComponentesRegistrarEmpresa.length;
        
        JButton BotonRegistrarEmpresa = new JButton("Registrar");
        BotonRegistrarEmpresa.setBounds(295, 380, 100, 15);
        BotonRegistrarEmpresa.addActionListener((ActionEvent e) -> {
            boolean BoolRegistrarEmpresa = true;
            for (int x = 0; x < ComponentesRegistrarEmpresaSize; x++){
                if (ComponentesRegistrarEmpresa[x].getText().equals("")){
                    BoolRegistrarEmpresa = false;
                    break;
                }
            }
            if (TextEmpresaSenal.getText().equals(""))
                    BoolRegistrarEmpresa = false;
            if (!BoolRegistrarEmpresa)
                JOptionPane.showMessageDialog(ventana, "Por favor rellene todos los espacios solicitados", "Error", JOptionPane.WARNING_MESSAGE);
            else {
                String nombre = TextEmpresaName.getText();
                String razonSocial = TextEmpresaRazon.getText();
                String cedula = TextEmpresaCedula.getText();
                String telefono = TextEmpresaTelefono.getText();
                String provincia = TextEmpresaProvincia.getItemAt(TextEmpresaProvincia.getSelectedIndex()).toString();
                String canton = TextEmpresaCanton.getText();
                String distrito = TextEmpresaDistrito.getText();
                String senas = TextEmpresaSenal.getText();
                String direccion = provincia + ", " + canton + ", " + distrito + ", " + senas;
                administradorEmpresas.crearEmpresa(nombre, razonSocial, cedula, telefono, direccion);
                JOptionPane.showMessageDialog(ventana, "Empresa creada con éxito", ":)", JOptionPane.INFORMATION_MESSAGE);
                for (int x = 0; x < ComponentesRegistrarEmpresaSize; x++)
                    ComponentesRegistrarEmpresa[x].setText("");
                TextEmpresaSenal.setText("");
                MenuRegistrarEmpresa.setVisible(false);
                ventana.add(MenuPrincipal);
                MenuPrincipal.setVisible(true);
                ventana.remove(MenuRegistrarEmpresa);
            }
            });
        
        //----------------------------------------------------------------------
        
        CuadroRegistrarEmpresa.add(TitleRegistrarEmpresa);
        CuadroRegistrarEmpresa.add(VolverRegistrarEmpresa);
        CuadroRegistrarEmpresa.add(BotonRegistrarEmpresa);
        CuadroRegistrarEmpresa.add(LabelEmpresaName);
        CuadroRegistrarEmpresa.add(TextEmpresaName);
        CuadroRegistrarEmpresa.add(LabelEmpresaRazon);
        CuadroRegistrarEmpresa.add(TextEmpresaRazon);
        CuadroRegistrarEmpresa.add(LabelEmpresaCedula);
        CuadroRegistrarEmpresa.add(TextEmpresaCedula);
        CuadroRegistrarEmpresa.add(LabelEmpresaTelefono);
        CuadroRegistrarEmpresa.add(TextEmpresaTelefono);
        CuadroRegistrarEmpresa.add(LabelEmpresaDireccion);
        CuadroRegistrarEmpresa.add(LabelEmpresaProvincia);
        CuadroRegistrarEmpresa.add(TextEmpresaProvincia);
        CuadroRegistrarEmpresa.add(LabelEmpresaCanton);
        CuadroRegistrarEmpresa.add(TextEmpresaCanton);
        CuadroRegistrarEmpresa.add(LabelEmpresaDistrito);
        CuadroRegistrarEmpresa.add(TextEmpresaDistrito);
        CuadroRegistrarEmpresa.add(LabelEmpresaSenal);
        CuadroRegistrarEmpresa.add(TextEmpresaSenal);
        
        /*  
         *  ####################################################################
         *  ###########---Componentes MenuRegistrarMantenimiento---#############
         *  ####################################################################
         */
        
        JPanel CuadroRegistrarMantenimiento = new JPanel();
        CuadroRegistrarMantenimiento.setBounds(340, 160, 400, 400);
        float[] reparando = Color.RGBtoHSB(255, 144, 107, null);
        CuadroRegistrarMantenimiento.setBackground(Color.getHSBColor(reparando[0], reparando[1], reparando[2]));
        CuadroRegistrarMantenimiento.setLayout(null);
        
        MenuRegistrarMantenimiento.add(CuadroRegistrarMantenimiento);
        
        JLabel TitleRegistrarMantenimiento = new JLabel("Registrar Servicio de mantenimiento");
        TitleRegistrarMantenimiento.setBounds(100, 5, 500, 20);
        
        String EmpresasEjemplo[] = {"Rent a Car", "La Toyota", "El Mecánico", "Otro mecánico", "La mutual"};
        
        String CarrosEjemplo[] = {"000000 - Placa - modelo", "000001 - Carro pruebas", "000002 - Carro bonito",
                                  "000003 - Carro feito", "000004 - EL CARRO PERFECTO", "000005 - EL carrito feo"};
        
        String ServiceType[] = {"Preventivo", "Correctivo"};
        
        JLabel LabelMantenimientoID = new JLabel("Identificador del servicio");
        LabelMantenimientoID.setBounds(5, 50, 400, 15);
        JTextField TextMantenimientoID = new JTextField();
        TextMantenimientoID.setBounds(150, 50, 230, 16);
        
        JLabel LabelMantenimientoEmpresa = new JLabel("Empresa a cargo");
        LabelMantenimientoEmpresa.setBounds(5, 70, 400, 15);
        JComboBox TextMantenimientoEmpresa = new JComboBox(EmpresasEjemplo);
        TextMantenimientoEmpresa.setBounds(150, 70, 230, 16);
        
        JLabel LabelMantenimientoVehiculo = new JLabel("Vehiculo");
        LabelMantenimientoVehiculo.setBounds(5, 90, 400, 15);
        JComboBox TextMantenimientoVehiculo = new JComboBox(CarrosEjemplo);
        TextMantenimientoVehiculo.setBounds(150, 90, 230, 16);
        
        JLabel LabelMantenimientoType = new JLabel("Tipo de servicio");
        LabelMantenimientoType.setBounds(5, 110, 400, 15);
        JComboBox TextMantenimientoType = new JComboBox(ServiceType);
        TextMantenimientoType.setBounds(150, 110, 230, 16);
        
        JLabel LabelMantenimientoActividad = new JLabel("Actividad a realizar");
        LabelMantenimientoActividad.setBounds(5, 130, 400, 15);
        JTextField TextMantenimientoActividad = new JTextField();
        TextMantenimientoActividad.setBounds(150, 130, 230, 16);
        
        JLabel LabelMantenimientoStart = new JLabel("Fecha de inicio                                    /                                     /");
        LabelMantenimientoStart.setBounds(5, 150, 400, 15);
        JComboBox TextMantenimientoStartDia = new JComboBox(Dia);
        TextMantenimientoStartDia.setBounds(150, 150, 40, 16);
        JComboBox TextMantenimientoStartMes = new JComboBox(Mes);
        TextMantenimientoStartMes.setBounds(205, 150, 100, 16);
        JComboBox TextMantenimientoStartAno = new JComboBox(AnoExpiracion);
        TextMantenimientoStartAno.setBounds(320, 150, 60, 16);
        
        JLabel LabelMantenimientoFin = new JLabel("Fecha de finalización                        /                                      /");
        LabelMantenimientoFin.setBounds(5, 170, 400, 15);
        JComboBox TextMantenimientoFinDia = new JComboBox(Dia);
        TextMantenimientoFinDia.setBounds(150, 170, 40, 16);
        JComboBox TextMantenimientoFinMes = new JComboBox(Mes);
        TextMantenimientoFinMes.setBounds(205, 170, 100, 16);
        JComboBox TextMantenimientoFinAno = new JComboBox(AnoExpiracion);
        TextMantenimientoFinAno.setBounds(320, 170, 60, 16);
        
        JLabel LabelMantenimientoMoney = new JLabel("Monto pagado");
        LabelMantenimientoMoney.setBounds(5, 190, 400, 15);
        JTextField TextMantenimientoMoney = new JTextField();
        TextMantenimientoMoney.setBounds(150, 190, 230, 16);
        
        JTextComponent[] textosRegistrarMantenimiento = {TextMantenimientoID, TextMantenimientoActividad, TextMantenimientoMoney};
        
        botonRegistrarMantenimiento.addActionListener((ActionEvent e) -> {
            try{
                TextMantenimientoEmpresa.removeAllItems();
                TextMantenimientoVehiculo.removeAllItems();
            }catch(Exception ex){}
            ArrayList<Vehiculo> otraListaVehiculos = adminOperador.getAdminVehiculo().getListaVehiculos();
            ArrayList<Empresa> otraListaEmpresa = administradorEmpresas.getListaEmpresas();
            for (int i = 0; i < otraListaVehiculos.size(); i++) {
                Vehiculo algunVehiculo = otraListaVehiculos.get(i);
                TextMantenimientoVehiculo.addItem(algunVehiculo.getPlaca()+" "+algunVehiculo.getMarca()); 
            }
            for (int i = 0; i < otraListaEmpresa.size(); i++) {
                Empresa algunaEmpresa = otraListaEmpresa.get(i);
                TextMantenimientoEmpresa.addItem(algunaEmpresa.getNombre());
                
            }
            
        });
        JButton BotonRegistrarMantenimiento = new JButton("Registrar");
        BotonRegistrarMantenimiento.setBounds(295, 380, 100, 15);
        BotonRegistrarMantenimiento.addActionListener((ActionEvent e) -> {
            //------- Requerimiento 4 en acción ------------
            if(!TextMantenimientoID.getText().equals("")&&!TextMantenimientoActividad.getText().equals("")&&
                    !TextMantenimientoMoney.getText().equals("")){
                Calendar fInicio=Calendar.getInstance();
                fInicio.set(Calendar.DATE,Integer.parseInt((String) TextMantenimientoStartDia.getSelectedItem()));
                fInicio.set(Calendar.MONTH,TextMantenimientoStartMes.getSelectedIndex());
                fInicio.set(Calendar.YEAR,Integer.parseInt((String) TextMantenimientoStartAno.getSelectedItem()));
                Calendar fFinal=Calendar.getInstance();
                fFinal.set(Calendar.DATE,Integer.parseInt((String) TextMantenimientoFinDia.getSelectedItem()));
                fFinal.set(Calendar.MONTH,TextMantenimientoStartMes.getSelectedIndex());
                fFinal.set(Calendar.YEAR,Integer.parseInt((String) TextMantenimientoFinAno.getSelectedItem()));
                boolean actService=administradorServicios.crearServicio(TextMantenimientoID.getText(),fInicio,
                        fFinal,Double.parseDouble(TextMantenimientoMoney.getText()),
                        TextMantenimientoActividad.getText(), (String) TextMantenimientoType.getSelectedItem(), 
                        (String) TextMantenimientoEmpresa.getSelectedItem());
                if(actService){
                    JOptionPane.showMessageDialog(null, "Servicio Creado", "Informativo", JOptionPane.INFORMATION_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(null, "Servicio ya Existe", "Informativo", JOptionPane.INFORMATION_MESSAGE);
                }
            }else{
                JOptionPane.showMessageDialog(null, "No deben haber espacios en blanco", "Informativo", JOptionPane.ERROR_MESSAGE);
            }
            clearText(textosRegistrarMantenimiento);
            MenuRegistrarMantenimiento.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuRegistrarMantenimiento);
            
            
        });
        
        JButton VolverRegistrarMantenimiento = new JButton("Volver");
        VolverRegistrarMantenimiento.setBounds(5, 380, 100, 15);
        VolverRegistrarMantenimiento.addActionListener((ActionEvent e) -> {
            clearText(textosRegistrarMantenimiento);
            MenuRegistrarMantenimiento.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuRegistrarMantenimiento);
        });
        
        //----------------------------------------------------------------------
        
        CuadroRegistrarMantenimiento.add(TitleRegistrarMantenimiento);
        CuadroRegistrarMantenimiento.add(VolverRegistrarMantenimiento);
        CuadroRegistrarMantenimiento.add(BotonRegistrarMantenimiento);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoID);
        CuadroRegistrarMantenimiento.add(TextMantenimientoID);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoEmpresa);
        CuadroRegistrarMantenimiento.add(TextMantenimientoEmpresa);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoVehiculo);
        CuadroRegistrarMantenimiento.add(TextMantenimientoVehiculo);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoType);
        CuadroRegistrarMantenimiento.add(TextMantenimientoType);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoActividad);
        CuadroRegistrarMantenimiento.add(TextMantenimientoActividad);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoStart);
        CuadroRegistrarMantenimiento.add(TextMantenimientoStartDia);
        CuadroRegistrarMantenimiento.add(TextMantenimientoStartMes);
        CuadroRegistrarMantenimiento.add(TextMantenimientoStartAno);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoFin);
        CuadroRegistrarMantenimiento.add(TextMantenimientoFinDia);
        CuadroRegistrarMantenimiento.add(TextMantenimientoFinMes);
        CuadroRegistrarMantenimiento.add(TextMantenimientoFinAno);
        CuadroRegistrarMantenimiento.add(LabelMantenimientoMoney);
        CuadroRegistrarMantenimiento.add(TextMantenimientoMoney);
        
        /*  
         *  ############################################################
         *  ###########---Componentes MenuEditarVehiculo---#############
         *  ############################################################
         */
        
        JPanel CuadroEditarVehiculo = new JPanel();
        CuadroEditarVehiculo.setBounds(190, 110, 700, 500);
        float[] moradito = Color.RGBtoHSB(146, 107, 255, null);
        CuadroEditarVehiculo.setBackground(Color.getHSBColor(moradito[0], moradito[1], moradito[2]));
        CuadroEditarVehiculo.setLayout(null);
        
        MenuEditarVehiculo.add(CuadroEditarVehiculo);
        
        JLabel TitleEditarVehiculo = new JLabel("Editar Vehículo");
        TitleEditarVehiculo.setBounds(315, 5, 500, 20);
        JButton VolverEditarVehiculo = new JButton("Volver");
        VolverEditarVehiculo.setBounds(5, 480, 100, 15);
        VolverEditarVehiculo.addActionListener((ActionEvent e) -> {
            MenuEditarVehiculo.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuEditarVehiculo);
        });
        
        ArrayList<Vehiculo> otraListaVehiculos = adminOperador.getAdminVehiculo().getListaVehiculos();
        String Placas[] = new String[otraListaVehiculos.size()+1];
        Placas[0]="Lista de placas";
        for (int i = 0; i < otraListaVehiculos.size(); i++) {
            Vehiculo algunVehiculo = otraListaVehiculos.get(i);
            Placas[i+1] = algunVehiculo.getPlaca();
        }
        
        JLabel LabelEditarPlaca = new JLabel("Placa");
        LabelEditarPlaca.setBounds(5, 50, 400, 15);
        JComboBox TextEditarPlaca = new JComboBox(Placas);
        TextEditarPlaca.setBounds(150, 50, 150, 16);
        
        JLabel LabelEditarMarca = new JLabel("Marca");
        LabelEditarMarca.setBounds(355, 50, 400, 15);
        JTextField TextEditarMarca = new JTextField();
        TextEditarMarca.setBounds(500, 50, 150, 16);
        
        JLabel LabelEditarEstilo = new JLabel("Estilo");
        LabelEditarEstilo.setBounds(5, 70, 400, 15);
        JComboBox TextEditarEstilo = new JComboBox(estilo);
        TextEditarEstilo.setBounds(150, 70, 150, 16);
        
        JLabel LabelEditarSucursal = new JLabel("Sucursal");
        LabelEditarSucursal.setBounds(355, 70, 400, 15);
        JTextField TextEditarSucursal = new JTextField();
        TextEditarSucursal.setBounds(500, 70, 150, 16);
        
        JLabel LabelEditarColor = new JLabel("Color");
        LabelEditarColor.setBounds(5, 90, 400, 15);
        JTextField TextEditarColor = new JTextField();
        TextEditarColor.setBounds(150, 90, 150, 16);
        
        JLabel LabelEditarCapacidad = new JLabel("Capacidad");
        LabelEditarCapacidad.setBounds(355, 90, 400, 15);
        JTextField TextEditarCapacidad = new JTextField();
        TextEditarCapacidad.setBounds(500, 90, 150, 16);
        
        JLabel LabelEditarPuertas = new JLabel("Numero de puertas");
        LabelEditarPuertas.setBounds(5, 110, 400, 15);
        JTextField TextEditarPuertas = new JTextField();
        TextEditarPuertas.setBounds(150, 110, 150, 16);
        
        JLabel LabelEditarMaletas = new JLabel("Capacidad de maletas");
        LabelEditarMaletas.setBounds(355, 110, 400, 15);
        JTextField TextEditarMaletas = new JTextField();
        TextEditarMaletas.setBounds(500, 110, 150, 16);
        
        JLabel LabelEditarFabricacion = new JLabel("Año de fabricación");
        LabelEditarFabricacion.setBounds(5, 130, 400, 15);
        JTextField TextEditarFabricacion = new JTextField();
        TextEditarFabricacion.setBounds(150, 130, 150, 16);
        
        JLabel LabelEditarVIN = new JLabel("Numero de Chasis"); //NumeroVin
        LabelEditarVIN.setBounds(355, 130, 400, 15);
        JTextField TextEditarVIN = new JTextField();
        TextEditarVIN.setBounds(500, 130, 150, 16);
        
        JLabel LabelEditarTransmision = new JLabel("Transmisión");
        LabelEditarTransmision.setBounds(5, 150, 400, 15);
        JComboBox TextEditarTransmision = new JComboBox(transmisión);
        TextEditarTransmision.setBounds(150, 150, 150, 16);
        
        JLabel LabelEditarKilometraje = new JLabel("Kilometraje");
        LabelEditarKilometraje.setBounds(355, 150, 400, 15);
        JTextField TextEditarKilometraje = new JTextField();
        TextEditarKilometraje.setBounds(500, 150, 150, 16);
        
        JLabel LabelEditarAlquiler = new JLabel("Costo de Alquiler");
        LabelEditarAlquiler.setBounds(5, 170, 400, 15);
        JTextField TextEditarAlquiler = new JTextField();
        TextEditarAlquiler.setBounds(150, 170, 150, 16);
        
        JLabel LabelEditarMPG = new JLabel("MPG (Millas por Galón)");
        LabelEditarMPG.setBounds(355, 170, 400, 15);
        JTextField TextEditarMPG = new JTextField();
        TextEditarMPG.setBounds(500, 170, 150, 16);
        
        JLabel LabelEditarFoto = new JLabel("Fotografía del vehículo");
        LabelEditarFoto.setBounds(5, 190, 400, 15);
        JButton BuscarEditarFoto = new JButton("Buscar...");
        BuscarEditarFoto.setBounds(500, 190, 100, 15);
        JTextField RutaEditarFoto = new JTextField();
        RutaEditarFoto.setBounds(150, 190, 330, 16);
        String[] otraFotoDir = new String[1];
        JLabel ImagenEditarFoto = new JLabel();
        ImagenEditarFoto.setBounds(100, 200, 500, 290);
        BuscarEditarFoto.addActionListener((ActionEvent f) ->{
            JFileChooser BuscarFoto = new JFileChooser();
            int returnValue = BuscarFoto.showOpenDialog(null);
            if(returnValue == JFileChooser.APPROVE_OPTION){
            File Foto = BuscarFoto.getSelectedFile();
            final String temp = Foto.getPath();
            otraFotoDir[0]=temp;
            RutaEditarFoto.setText(temp);
            ImagenEditarFoto.setIcon(new ImageIcon(Foto.getPath()));
            }
        });
        RutaEditarFoto.setEditable(false);
        //Implementar en el archivo final
        botonEditarVehiculo.addActionListener((ActionEvent e) -> {
            try{
                TextEditarPlaca.removeAllItems();
            }catch(Exception ex){}
            ArrayList<Vehiculo> listaVehiculos = adminOperador.getAdminVehiculo().getListaVehiculos();
            TextEditarPlaca.addItem("Lista de placas");
            for (int i = 0; i < listaVehiculos.size(); i++) {
                Vehiculo algunVehiculo = listaVehiculos.get(i);
                TextEditarPlaca.addItem(algunVehiculo.getPlaca()); 
            }
            
        });
        //Implementar en el archivo final
        TextEditarPlaca.addActionListener((ActionEvent e) -> {
            try{
            String actPlaca=(String)TextEditarPlaca.getSelectedItem();
            Vehiculo actVehiculo = adminOperador.getAdminVehiculo().buscarVehiculo(actPlaca);
            TextEditarMarca.setText(actVehiculo.getMarca());
            TextEditarEstilo.setSelectedItem(obtenerEstilo(actVehiculo.getEstilo()));
            TextEditarSucursal.setText(actVehiculo.getSucursal());
            TextEditarColor.setText(actVehiculo.getColor());
            TextEditarCapacidad.setText(String.valueOf(actVehiculo.getCapacidad()));
            TextEditarPuertas.setText(String.valueOf(actVehiculo.getNumeroPuertas()));
            TextEditarMaletas.setText(String.valueOf(actVehiculo.getCapacidadMaletas()));
            TextEditarFabricacion.setText(String.valueOf(actVehiculo.getAnnoFabricacion()));
            TextEditarVIN.setText(actVehiculo.getNumeroVin());
            TextEditarTransmision.setSelectedItem(obtenerTransmision(actVehiculo.getTipoTransmision()));
            TextEditarKilometraje.setText(String.valueOf(actVehiculo.getKilometraje()));
            TextEditarAlquiler.setText(String.valueOf(actVehiculo.getCostoAlquiler()));
            TextEditarMPG.setText(String.valueOf(actVehiculo.getMpg()));
            RutaEditarFoto.setText(actVehiculo.getFoto());
            ImagenEditarFoto.setIcon(new ImageIcon(actVehiculo.getFoto()));
            }catch(Exception ex){}
        });
        
        JButton BotonEditarVehiculo = new JButton("Guardar cambios");
        BotonEditarVehiculo.setBounds(545, 480, 150, 15);
        BotonEditarVehiculo.addActionListener((ActionEvent e) -> {
            estilo otroEstiloVehiculo;
            if(TextEditarEstilo.getItemAt(TextEditarEstilo.getSelectedIndex()).toString() == "MiniVan"){
                otroEstiloVehiculo = modelo.estilo.MiniVan;
            }else if(TextEditarEstilo.getItemAt(TextEditarEstilo.getSelectedIndex()).toString() == "compacto"){
                otroEstiloVehiculo = modelo.estilo.compacto;
            }else if(TextEditarEstilo.getItemAt(TextEditarEstilo.getSelectedIndex()).toString() == "SUV"){
                otroEstiloVehiculo = modelo.estilo.SUV;
            }else if(TextEditarEstilo.getItemAt(TextEditarEstilo.getSelectedIndex()).toString() == "intermedio"){
                otroEstiloVehiculo = modelo.estilo.intermedio;
            }else if(TextEditarEstilo.getItemAt(TextEditarEstilo.getSelectedIndex()).toString() == "pickup"){
                otroEstiloVehiculo = modelo.estilo.pickup;
            }else{
                otroEstiloVehiculo = modelo.estilo.convertible_economico;
            }
            transmision otroTipoTransmision;
            if(TextEditarTransmision.getItemAt(TextEditarTransmision.getSelectedIndex()).toString() == "Manual"){
                otroTipoTransmision = transmision.manual;
            }else{
                otroTipoTransmision = transmision.automata;
            }
            Vehiculo cualquierVehiculo = adminOperador.getAdminVehiculo().buscarVehiculo(TextEditarPlaca.getItemAt(TextEditarPlaca.getSelectedIndex()).toString());
            cualquierVehiculo.setAnnoFabricacion(Integer.parseInt(TextEditarFabricacion.getText()));
            cualquierVehiculo.setCapacidad(Integer.parseInt(TextEditarCapacidad.getText()));
            cualquierVehiculo.setCapacidadMaletas(Integer.parseInt(TextEditarMaletas.getText()));
            cualquierVehiculo.setColor(TextEditarColor.getText());
            cualquierVehiculo.setCostoAlquiler(Double.parseDouble(TextEditarAlquiler.getText()));
            cualquierVehiculo.setEstilo(otroEstiloVehiculo);
            cualquierVehiculo.setKilometraje(Double.parseDouble(TextEditarKilometraje.getText()));
            cualquierVehiculo.setMarca(TextEditarMarca.getText());
            cualquierVehiculo.setMpg(Double.parseDouble(TextEditarMPG.getText()));
            cualquierVehiculo.setNumeroPuertas(Integer.parseInt(TextEditarPuertas.getText()));
            cualquierVehiculo.setNumeroVin(TextEditarVIN.getText());
            cualquierVehiculo.setSucursal(TextEditarSucursal.getText());
            cualquierVehiculo.setTipoTransmision(otroTipoTransmision);
            cualquierVehiculo.setFoto(otraFotoDir[0]);
            
            JOptionPane.showMessageDialog(ventana, "Cambios Guardados con éxito", ":)", JOptionPane.INFORMATION_MESSAGE);
            MenuEditarVehiculo.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuEditarVehiculo);
        });
        
        //---------------------------------------------------------------------
        
        CuadroEditarVehiculo.add(TitleEditarVehiculo);
        CuadroEditarVehiculo.add(VolverEditarVehiculo);
        CuadroEditarVehiculo.add(LabelEditarPlaca);
        CuadroEditarVehiculo.add(TextEditarPlaca);
        CuadroEditarVehiculo.add(LabelEditarMarca);
        CuadroEditarVehiculo.add(TextEditarMarca);
        CuadroEditarVehiculo.add(LabelEditarFabricacion);
        CuadroEditarVehiculo.add(TextEditarFabricacion);
        CuadroEditarVehiculo.add(LabelEditarEstilo);
        CuadroEditarVehiculo.add(TextEditarEstilo);
        CuadroEditarVehiculo.add(LabelEditarColor);
        CuadroEditarVehiculo.add(TextEditarColor);
        CuadroEditarVehiculo.add(LabelEditarCapacidad);
        CuadroEditarVehiculo.add(TextEditarCapacidad);
        CuadroEditarVehiculo.add(LabelEditarKilometraje);
        CuadroEditarVehiculo.add(TextEditarKilometraje);
        CuadroEditarVehiculo.add(LabelEditarPuertas);
        CuadroEditarVehiculo.add(TextEditarPuertas);
        CuadroEditarVehiculo.add(LabelEditarVIN);
        CuadroEditarVehiculo.add(TextEditarVIN);
        CuadroEditarVehiculo.add(LabelEditarMPG);
        CuadroEditarVehiculo.add(TextEditarMPG);
        CuadroEditarVehiculo.add(LabelEditarSucursal);
        CuadroEditarVehiculo.add(TextEditarSucursal);
        CuadroEditarVehiculo.add(LabelEditarAlquiler);
        CuadroEditarVehiculo.add(TextEditarAlquiler);
        CuadroEditarVehiculo.add(LabelEditarMaletas);
        CuadroEditarVehiculo.add(TextEditarMaletas);
        CuadroEditarVehiculo.add(LabelEditarTransmision);
        CuadroEditarVehiculo.add(TextEditarTransmision);
        CuadroEditarVehiculo.add(LabelEditarFoto);
        CuadroEditarVehiculo.add(BuscarEditarFoto);
        CuadroEditarVehiculo.add(RutaEditarFoto);
        CuadroEditarVehiculo.add(VolverEditarVehiculo);
        CuadroEditarVehiculo.add(BotonEditarVehiculo);
        CuadroEditarVehiculo.add(ImagenEditarFoto);
        
        /*  
         *  ####################################################################
         *  ###########---Componentes SubMenuInformaciónVehiculo---#############
         *  ####################################################################
         */
        
        JPanel CuadroInformacionVehiculo = new JPanel();
        JPanel CuadroConsultarReserva = new JPanel();
        CuadroInformacionVehiculo.setBackground(Color.getHSBColor(unColor[0], unColor[1], unColor[2]));
        CuadroInformacionVehiculo.setLayout(null);
        CuadroInformacionVehiculo.setVisible(true);
        
        JLabel TitleInformacionVehiculo = new JLabel("Información Vehículo");
        TitleInformacionVehiculo.setBounds(290, 5, 500, 20);
        JButton VolverInformacionVehiculo = new JButton("Volver");
        VolverInformacionVehiculo.setBounds(5, 480, 100, 15);
        VolverInformacionVehiculo.addActionListener((ActionEvent e) -> {
            CuadroInformacionVehiculo.setVisible(false);
            MenuConsultarReserva.add(CuadroConsultarReserva);
            CuadroConsultarReserva.setVisible(true);
            MenuConsultarReserva.remove(CuadroInformacionVehiculo);
        });

        JLabel LabelVehiculoInfPlaca = new JLabel("Placa");
        LabelVehiculoInfPlaca.setBounds(5, 50, 400, 15);
        JTextField TextVehiculoInfPlaca = new JTextField();
        TextVehiculoInfPlaca.setBounds(150, 50, 150, 16);
        TextVehiculoInfPlaca.setEditable(false);
        
        JLabel LabelVehiculoInfMarca = new JLabel("Marca");
        LabelVehiculoInfMarca.setBounds(355, 50, 400, 15);
        JTextField TextVehiculoInfMarca = new JTextField();
        TextVehiculoInfMarca.setBounds(500, 50, 150, 16);
        TextVehiculoInfMarca.setEditable(false);
        
        JLabel LabelVehiculoInfEstilo = new JLabel("Estilo");
        LabelVehiculoInfEstilo.setBounds(5, 70, 400, 15);
        JTextField TextVehiculoInfEstilo = new JTextField();
        TextVehiculoInfEstilo.setBounds(150, 70, 150, 16);
        TextVehiculoInfEstilo.setEditable(false);
        
        JLabel LabelVehiculoInfSucursal = new JLabel("Sucursal");
        LabelVehiculoInfSucursal.setBounds(355, 70, 400, 15);
        JTextField TextVehiculoInfSucursal = new JTextField();
        TextVehiculoInfSucursal.setBounds(500, 70, 150, 16);
        TextVehiculoInfSucursal.setEditable(false);
        
        JLabel LabelVehiculoInfColor = new JLabel("Color");
        LabelVehiculoInfColor.setBounds(5, 90, 400, 15);
        JTextField TextVehiculoInfColor = new JTextField();
        TextVehiculoInfColor.setBounds(150, 90, 150, 16);
        TextVehiculoInfColor.setEditable(false);
        
        JLabel LabelVehiculoInfCapacidad = new JLabel("Capacidad");
        LabelVehiculoInfCapacidad.setBounds(355, 90, 400, 15);
        JTextField TextVehiculoInfCapacidad = new JTextField();
        TextVehiculoInfCapacidad.setBounds(500, 90, 150, 16);
        TextVehiculoInfCapacidad.setEditable(false);
        
        JLabel LabelVehiculoInfPuertas = new JLabel("Numero de puertas");
        LabelVehiculoInfPuertas.setBounds(5, 110, 400, 15);
        JTextField TextVehiculoInfPuertas = new JTextField();
        TextVehiculoInfPuertas.setBounds(150, 110, 150, 16);
        TextVehiculoInfPuertas.setEditable(false);
        
        JLabel LabelVehiculoInfMaletas = new JLabel("Capacidad de maletas");
        LabelVehiculoInfMaletas.setBounds(355, 110, 400, 15);
        JTextField TextVehiculoInfMaletas = new JTextField();
        TextVehiculoInfMaletas.setBounds(500, 110, 150, 16);
        TextVehiculoInfMaletas.setEditable(false);
        
        JLabel LabelVehiculoInfFabricacion = new JLabel("Año de fabricación");
        LabelVehiculoInfFabricacion.setBounds(5, 130, 400, 15);
        JTextField TextVehiculoInfFabricacion = new JTextField();
        TextVehiculoInfFabricacion.setBounds(150, 130, 150, 16);
        TextVehiculoInfFabricacion.setEditable(false);
        
        JLabel LabelVehiculoInfVIN = new JLabel("Numero de Chasis"); //NumeroVin
        LabelVehiculoInfVIN.setBounds(355, 130, 400, 15);
        JTextField TextVehiculoInfVIN = new JTextField();
        TextVehiculoInfVIN.setBounds(500, 130, 150, 16);
        TextVehiculoInfVIN.setEditable(false);
        
        JLabel LabelVehiculoInfTransmision = new JLabel("Transmisión");
        LabelVehiculoInfTransmision.setBounds(5, 150, 400, 15);
        JTextField TextVehiculoInfTransmision = new JTextField();
        TextVehiculoInfTransmision.setBounds(150, 150, 150, 16);
        TextVehiculoInfTransmision.setEditable(false);
        
        JLabel LabelVehiculoInfKilometraje = new JLabel("Kilometraje");
        LabelVehiculoInfKilometraje.setBounds(355, 150, 400, 15);
        JTextField TextVehiculoInfKilometraje = new JTextField();
        TextVehiculoInfKilometraje.setBounds(500, 150, 150, 16);
        TextVehiculoInfKilometraje.setEditable(false);
        
        JLabel LabelVehiculoInfAlquiler = new JLabel("Costo de Alquiler");
        LabelVehiculoInfAlquiler.setBounds(5, 170, 400, 15);
        JTextField TextVehiculoInfAlquiler = new JTextField();
        TextVehiculoInfAlquiler.setBounds(150, 170, 150, 16);
        TextVehiculoInfAlquiler.setEditable(false);
        
        JLabel LabelVehiculoInfMPG = new JLabel("MPG (Millas por Galón)");
        LabelVehiculoInfMPG.setBounds(355, 170, 400, 15);
        JTextField TextVehiculoInfMPG = new JTextField();
        TextVehiculoInfMPG.setBounds(500, 170, 150, 16);
        TextVehiculoInfMPG.setEditable(false);
        
        JLabel LabelVehiculoInfFoto = new JLabel("Fotografía del vehículo");
        LabelVehiculoInfFoto.setBounds(280, 200, 400, 15);
        
        //---------------------------------------------------------------------
        
        CuadroInformacionVehiculo.add(TitleInformacionVehiculo);
        CuadroInformacionVehiculo.add(LabelVehiculoInfPlaca);
        CuadroInformacionVehiculo.add(TextVehiculoInfPlaca);
        CuadroInformacionVehiculo.add(LabelVehiculoInfMarca);
        CuadroInformacionVehiculo.add(TextVehiculoInfMarca);
        CuadroInformacionVehiculo.add(LabelVehiculoInfFabricacion);
        CuadroInformacionVehiculo.add(TextVehiculoInfFabricacion);
        CuadroInformacionVehiculo.add(LabelVehiculoInfEstilo);
        CuadroInformacionVehiculo.add(TextVehiculoInfEstilo);
        CuadroInformacionVehiculo.add(LabelVehiculoInfColor);
        CuadroInformacionVehiculo.add(TextVehiculoInfColor);
        CuadroInformacionVehiculo.add(LabelVehiculoInfCapacidad);
        CuadroInformacionVehiculo.add(TextVehiculoInfCapacidad);
        CuadroInformacionVehiculo.add(LabelVehiculoInfKilometraje);
        CuadroInformacionVehiculo.add(TextVehiculoInfKilometraje);
        CuadroInformacionVehiculo.add(LabelVehiculoInfPuertas);
        CuadroInformacionVehiculo.add(TextVehiculoInfPuertas);
        CuadroInformacionVehiculo.add(LabelVehiculoInfVIN);
        CuadroInformacionVehiculo.add(TextVehiculoInfVIN);
        CuadroInformacionVehiculo.add(LabelVehiculoInfMPG);
        CuadroInformacionVehiculo.add(TextVehiculoInfMPG);
        CuadroInformacionVehiculo.add(LabelVehiculoInfSucursal);
        CuadroInformacionVehiculo.add(TextVehiculoInfSucursal);
        CuadroInformacionVehiculo.add(LabelVehiculoInfAlquiler);
        CuadroInformacionVehiculo.add(TextVehiculoInfAlquiler);
        CuadroInformacionVehiculo.add(LabelVehiculoInfMaletas);
        CuadroInformacionVehiculo.add(TextVehiculoInfMaletas);
        CuadroInformacionVehiculo.add(LabelVehiculoInfTransmision);
        CuadroInformacionVehiculo.add(TextVehiculoInfTransmision);
        CuadroInformacionVehiculo.add(LabelVehiculoInfFoto);
        CuadroInformacionVehiculo.add(VolverInformacionVehiculo);
        
        /*  
         *  ###################################################################
         *  ###########---Componentes SubMenuInformaciónCliente---#############
         *  ###################################################################
         */
        
        JPanel CuadroInformacionCliente = new JPanel();
        CuadroInformacionCliente.setBackground(Color.getHSBColor(celestico[0], celestico[1], celestico[2]));
        CuadroInformacionCliente.setLayout(null);
        CuadroInformacionCliente.setVisible(true);
        
        JLabel TitleInformacionCliente = new JLabel("Información del cliente");
        TitleInformacionCliente.setBounds(170, 5, 500, 20);
        JButton VolverInformacionCliente = new JButton("Volver");
        VolverInformacionCliente.setBounds(5, 480, 100, 15);
        VolverInformacionCliente.addActionListener((ActionEvent e) -> {
            CuadroInformacionCliente.setVisible(false);
            MenuConsultarReserva.add(CuadroConsultarReserva);
            CuadroConsultarReserva.setVisible(true);
            MenuConsultarReserva.remove(CuadroInformacionCliente);
        });
        
        JLabel LabelClienteInfNombre = new JLabel("Nombre Completo");
        LabelClienteInfNombre.setBounds(5, 50, 400, 15);
        JTextField TextlClienteInfNombre = new JTextField();
        TextlClienteInfNombre.setBounds(150, 50, 330, 16);
        TextlClienteInfNombre.setEditable(false);
        
        JLabel LabelClienteInfCedula = new JLabel("Cédula");
        LabelClienteInfCedula.setBounds(5, 70, 400, 15);
        JTextField TextlClienteInfCedula = new JTextField();
        TextlClienteInfCedula.setBounds(150, 70, 330, 16);
        TextlClienteInfCedula.setEditable(false);
        
        JLabel LabelClienteInfEmail = new JLabel("Correo electrónico");
        LabelClienteInfEmail.setBounds(5, 90, 400, 15);
        JTextField TextlClienteInfEmail = new JTextField();
        TextlClienteInfEmail.setBounds(150, 90, 330, 16);
        TextlClienteInfEmail.setEditable(false);
        
        JLabel LabelClienteInfTelefono = new JLabel("Número de teléfono");
        LabelClienteInfTelefono.setBounds(5, 110, 400, 15);
        JTextField TextlClienteInfTelefono = new JTextField();
        TextlClienteInfTelefono.setBounds(150, 110, 330, 16);
        TextlClienteInfTelefono.setEditable(false);
        
        JLabel LabelClienteInfDireccion = new JLabel("Dirección exacta");
        LabelClienteInfDireccion.setBounds(5, 130, 400, 15);
        JTextArea TextlClienteInfDireccion = new JTextArea();
        TextlClienteInfDireccion.setBounds(150, 130, 330, 96);
        TextlClienteInfDireccion.setEditable(false);
        
        JLabel LabelClienteInfNumeroLic = new JLabel("Número de licencia");
        LabelClienteInfNumeroLic.setBounds(5, 230, 400, 15);
        JTextField TextlClienteInfNumeroLic = new JTextField();
        TextlClienteInfNumeroLic.setBounds(150, 230, 330, 16);
        TextlClienteInfNumeroLic.setEditable(false);
        
        JLabel LabelClienteInfType = new JLabel("Tipo de licencia");
        LabelClienteInfType.setBounds(5, 250, 400, 15);
        JTextField TextlClienteInfType = new JTextField();
        TextlClienteInfType.setBounds(150, 250, 330, 16);
        TextlClienteInfType.setEditable(false);
        
        JLabel LabelClienteInfEmision = new JLabel("Fecha de emisión de la licencia");
        LabelClienteInfEmision.setBounds(5, 270, 400, 15);
        JTextField TextlClienteInfEmision = new JTextField();
        TextlClienteInfEmision.setBounds(200, 270, 280, 16);
        TextlClienteInfEmision.setEditable(false);
        
        JLabel LabelClienteInfExpiracion = new JLabel("Fecha de expiración de la licencia");
        LabelClienteInfExpiracion.setBounds(5, 290, 400, 15);
        JTextField TextlClienteInfExpiracion = new JTextField();
        TextlClienteInfExpiracion.setBounds(200, 290, 280, 16);
        TextlClienteInfExpiracion.setEditable(false);
        
        JLabel LabelClienteInfFoto = new JLabel("Fotografía de la licencia");
        LabelClienteInfFoto.setBounds(180, 320, 400, 15);
        
        
        
        //----------------------------------------------------------------------
        
        CuadroInformacionCliente.add(TitleInformacionCliente);
        CuadroInformacionCliente.add(VolverInformacionCliente);
        CuadroInformacionCliente.add(LabelClienteInfNombre);
        CuadroInformacionCliente.add(TextlClienteInfNombre);
        CuadroInformacionCliente.add(LabelClienteInfCedula);
        CuadroInformacionCliente.add(TextlClienteInfCedula);
        CuadroInformacionCliente.add(LabelClienteInfDireccion);
        CuadroInformacionCliente.add(TextlClienteInfDireccion);
        CuadroInformacionCliente.add(LabelClienteInfEmail);
        CuadroInformacionCliente.add(TextlClienteInfEmail);
        CuadroInformacionCliente.add(LabelClienteInfTelefono);
        CuadroInformacionCliente.add(TextlClienteInfTelefono);
        CuadroInformacionCliente.add(LabelClienteInfFoto);
        CuadroInformacionCliente.add(LabelClienteInfNumeroLic);
        CuadroInformacionCliente.add(TextlClienteInfNumeroLic);
        CuadroInformacionCliente.add(LabelClienteInfType);
        CuadroInformacionCliente.add(TextlClienteInfType);
        CuadroInformacionCliente.add(LabelClienteInfEmision);
        CuadroInformacionCliente.add(TextlClienteInfEmision);
        CuadroInformacionCliente.add(LabelClienteInfExpiracion);
        CuadroInformacionCliente.add(TextlClienteInfExpiracion);
        
        
        
        /*  
         *  ##############################################################
         *  ###########---Componentes MenuConsultarReserva---#############
         *  ##############################################################
         */
        
        CuadroConsultarReserva.setBounds(190, 110, 700, 500);
        CuadroInformacionCliente.setBounds(290, 110, 500, 500);
        CuadroInformacionVehiculo.setBounds(190, 110, 700, 500);
        float[] limoncito = Color.RGBtoHSB(198, 255, 107, null);
        CuadroConsultarReserva.setBackground(Color.getHSBColor(limoncito[0], limoncito[1], limoncito[2]));
        CuadroConsultarReserva.setLayout(null);
        
        MenuConsultarReserva.add(CuadroConsultarReserva);
        MenuConsultarReserva.setVisible(true);
        MenuConsultarReserva.setLayout(null);
        
        JLabel TitleConsultarReserva = new JLabel("Consultar Reserva");
        TitleConsultarReserva.setBounds(300, 5, 500, 20);
        JButton VolverConsultarReserva = new JButton("Volver");
        VolverConsultarReserva.setBounds(5, 480, 100, 15);
        VolverConsultarReserva.addActionListener((ActionEvent e) -> {
            MenuConsultarReserva.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuConsultarReserva);
        });
        
        String Reservas[] = {};
        
        JLabel LabelConsultarNumero = new JLabel("Número de factura");
        LabelConsultarNumero.setBounds(155, 50, 400, 15);
        JComboBox TextConsultarNumero = new JComboBox(Reservas);
        TextConsultarNumero.setBounds(300, 50, 230, 16);
        
        JLabel LabelConsultarRecogida = new JLabel("Sede de recogida");
        LabelConsultarRecogida.setBounds(155, 70, 400, 15);
        JTextField TextConsultarRecogida = new JTextField();
        TextConsultarRecogida.setBounds(300, 70, 230, 16);
        TextConsultarRecogida.setEditable(false);
        
        JLabel LabelConsultarEntrega = new JLabel("Sede de entrega");
        LabelConsultarEntrega.setBounds(155, 90, 400, 15);
        JTextField TextConsultarEntrega = new JTextField();
        TextConsultarEntrega.setBounds(300, 90, 230, 16);
        TextConsultarEntrega.setEditable(false);
        
        JLabel LabelConsultarInicio = new JLabel("Fecha de inicio");
        LabelConsultarInicio.setBounds(155, 110, 400, 15);
        JTextField TextConsultarInicio = new JTextField();
        TextConsultarInicio.setBounds(300, 110, 230, 16);
        TextConsultarInicio.setEditable(false);
        
        JLabel LabelConsultarFinal = new JLabel("Fecha de entrega");
        LabelConsultarFinal.setBounds(155, 130, 400, 15);
        JTextField TextConsultarFinal = new JTextField();
        TextConsultarFinal.setBounds(300, 130, 230, 16);
        TextConsultarFinal.setEditable(false);
        
        JLabel LabelConsultarReservacion = new JLabel("Fecha de reservación");
        LabelConsultarReservacion.setBounds(155, 150, 400, 15);
        JTextField TextConsultarReservacion = new JTextField();
        TextConsultarReservacion.setBounds(300, 150, 230, 16);
        TextConsultarReservacion.setEditable(false);
        
        JLabel LabelConsultarVehiculo = new JLabel("Vehículo");
        LabelConsultarVehiculo.setBounds(155, 170, 400, 15);
        JTextField TextConsultarVehiculo = new JTextField();
        TextConsultarVehiculo.setBounds(300, 170, 230, 16);
        TextConsultarVehiculo.setEditable(false);
        JButton BotonConsultarVehiculo = new JButton("Información del vehículo");
        BotonConsultarVehiculo.setBounds(200, 260, 300, 50);
        
         BotonConsultarVehiculo.addActionListener((ActionEvent e) -> {
            String numReserva=(String)TextConsultarNumero.getSelectedItem();
            ArrayList parametros=adminOperador.consultaReserva(Integer.parseInt(numReserva));
            Vehiculo carro=(Vehiculo)parametros.get(2);
            
            TextVehiculoInfPlaca.setText(carro.getPlaca());
            TextVehiculoInfMarca.setText(carro.getMarca());
            TextVehiculoInfEstilo.setText(obtenerEstilo(carro.getEstilo()));
            TextVehiculoInfSucursal.setText(carro.getSucursal());
            TextVehiculoInfColor.setText(carro.getColor());
            TextVehiculoInfCapacidad.setText(String.valueOf(carro.getCapacidad()));
            TextVehiculoInfPuertas.setText(String.valueOf(carro.getNumeroPuertas()));
            TextVehiculoInfMaletas.setText(String.valueOf(carro.getCapacidadMaletas()));
            TextVehiculoInfFabricacion.setText(String.valueOf(carro.getAnnoFabricacion()));
            TextVehiculoInfVIN.setText(carro.getNumeroVin());
            TextVehiculoInfTransmision.setText(obtenerTransmision(carro.getTipoTransmision()));
            TextVehiculoInfKilometraje.setText(String.valueOf(carro.getKilometraje()));
            TextVehiculoInfAlquiler.setText(String.valueOf(carro.getCostoAlquiler()));
            TextVehiculoInfMPG.setText(String.valueOf(carro.getMpg()));
            CuadroConsultarReserva.setVisible(false);
            MenuConsultarReserva.remove(CuadroConsultarReserva);
            MenuConsultarReserva.setVisible(true);
            MenuConsultarReserva.setLayout(null);
            MenuConsultarReserva.add(CuadroInformacionVehiculo);
            CuadroInformacionVehiculo.setVisible(true);
        });
        
        JLabel LabelConsultarCliente = new JLabel("Cliente");
        LabelConsultarCliente.setBounds(155, 190, 400, 15);
        JTextField TextConsultarCliente = new JTextField();
        TextConsultarCliente.setBounds(300, 190, 230, 16);
        TextConsultarCliente.setEditable(false);
        JButton BotonConsultarCliente = new JButton("Información del cliente");
        BotonConsultarCliente.setBounds(200, 360, 300, 50);
        //Cambiar ihdwiduhfiuhihfi
        
        
        botonConsultarReserva.addActionListener((ActionEvent e) -> {
            try{
                TextConsultarNumero.removeAllItems();
            }catch(Exception ex){}
            String[] lista=adminOperador.listaNumreservas();
            for (int i = 0; i < lista.length; i++) {
                TextConsultarNumero.addItem(lista[i]);
            }
            
        });
        BotonConsultarCliente.addActionListener((ActionEvent e) -> {
            String numReserva=(String)TextConsultarNumero.getSelectedItem();
            ArrayList parametros=adminOperador.consultaReserva(Integer.parseInt(numReserva));
            Cliente persona=(Cliente)parametros.get(1);
            TextlClienteInfNombre.setText(persona.getNombre());
            TextlClienteInfCedula.setText(persona.getCedula());
            TextlClienteInfEmail.setText(persona.getCorreoElectronico());
            TextlClienteInfTelefono.setText(persona.getTelefono());
            TextlClienteInfDireccion.setText(persona.getDireccion());
            TextlClienteInfNumeroLic.setText(persona.numLicenciaCliente());
            TextlClienteInfType.setText(persona.tipoLicenciaCliente());
            TextlClienteInfEmision.setText(formatoFecha(persona.fechEmisionCliente()));
            TextlClienteInfExpiracion.setText(formatoFecha(persona.fechExpiraCliente()));
            CuadroConsultarReserva.setVisible(false);
            MenuConsultarReserva.remove(CuadroConsultarReserva);
            MenuConsultarReserva.setVisible(true);
            MenuConsultarReserva.setLayout(null);
            MenuConsultarReserva.add(CuadroInformacionCliente);
            CuadroInformacionCliente.setVisible(true);
        });
        
        //agregar al final del programa
        TextConsultarNumero.addActionListener((ActionEvent e)->{
            String numReserva=(String)TextConsultarNumero.getSelectedItem();
            ArrayList parametros=adminOperador.consultaReserva(Integer.parseInt(numReserva));
            Reservas reserva=(Reservas)parametros.get(0);
            Cliente persona=(Cliente)parametros.get(1);
            Vehiculo carro=(Vehiculo)parametros.get(2);
            TextConsultarRecogida.setText(reserva.getSedeRecogida());
            TextConsultarEntrega.setText(reserva.getSedeEntrega());
            TextConsultarInicio.setText(formatoFecha(reserva.getFechaInicio()));
            TextConsultarFinal.setText(formatoFecha(reserva.getFechaFinal()));
            TextConsultarVehiculo.setText(carro.getPlaca());
            TextConsultarCliente.setText(persona.getNombre());
        });
        
        //----------------------------------------------------------------------
        
        CuadroConsultarReserva.add(TitleConsultarReserva);
        CuadroConsultarReserva.add(VolverConsultarReserva);
        CuadroConsultarReserva.add(LabelConsultarNumero);
        CuadroConsultarReserva.add(TextConsultarNumero);
        CuadroConsultarReserva.add(LabelConsultarRecogida);
        CuadroConsultarReserva.add(TextConsultarRecogida);
        CuadroConsultarReserva.add(LabelConsultarEntrega);
        CuadroConsultarReserva.add(TextConsultarEntrega);
        CuadroConsultarReserva.add(LabelConsultarInicio);
        CuadroConsultarReserva.add(TextConsultarInicio);
        CuadroConsultarReserva.add(LabelConsultarFinal);
        CuadroConsultarReserva.add(TextConsultarFinal);
        CuadroConsultarReserva.add(LabelConsultarReservacion);
        CuadroConsultarReserva.add(TextConsultarReservacion);
        CuadroConsultarReserva.add(LabelConsultarVehiculo);
        CuadroConsultarReserva.add(TextConsultarVehiculo);
        CuadroConsultarReserva.add(BotonConsultarVehiculo);
        CuadroConsultarReserva.add(LabelConsultarCliente);
        CuadroConsultarReserva.add(TextConsultarCliente);
        CuadroConsultarReserva.add(BotonConsultarCliente);
        
        /*  
         *  #################################################################
         *  ###########---Componentes SubMenuConfirmarReserva---#############
         *  #################################################################
         */
        
        JPanel CuadroConfirmarReserva = new JPanel();
        CuadroConfirmarReserva.setBounds(190, 110, 700, 500);
        CuadroConfirmarReserva.setBackground(Color.getHSBColor(limoncito[0], limoncito[1], limoncito[2]));
        CuadroConfirmarReserva.setLayout(null);
        
        JLabel TitleConfirmarReserva = new JLabel("Detalles de la reserva");
        TitleConfirmarReserva.setBounds(300, 5, 500, 20);
        
        JTextField TextConfirmarNumero = new JTextField();
        TextConfirmarNumero.setBounds(300, 50, 230, 16);
        TextConfirmarNumero.setEditable(false);
        
        JButton BotonVolverConfirmarVehiculo = new JButton("Volver");
        JButton BotonVolverConfirmarCliente = new JButton("Volver");
        BotonVolverConfirmarVehiculo.setBounds(5, 480, 100, 15);
        BotonVolverConfirmarCliente.setBounds(5, 480, 100, 15);
        BotonVolverConfirmarVehiculo.addActionListener((ActionEvent e)->{
            CuadroInformacionVehiculo.add(VolverInformacionVehiculo);
            CuadroInformacionVehiculo.remove(BotonVolverConfirmarVehiculo);
            
            CuadroInformacionVehiculo.setVisible(false);
            MenuHacerReserva.remove(CuadroInformacionVehiculo);
            MenuHacerReserva.add(CuadroConfirmarReserva);
            CuadroConfirmarReserva.setVisible(true);
        });
        BotonVolverConfirmarCliente.addActionListener((ActionEvent e)->{
            CuadroInformacionCliente.add(VolverInformacionCliente);
            CuadroInformacionCliente.remove(BotonVolverConfirmarCliente);
            
            CuadroInformacionCliente.setVisible(false);
            MenuHacerReserva.remove(CuadroInformacionCliente);
            MenuHacerReserva.add(CuadroConfirmarReserva);
            CuadroConfirmarReserva.setVisible(true);
        });
        
        JButton BotonConfirmarVehiculo = new JButton("Información del vehículo");
        BotonConfirmarVehiculo.setBounds(200, 260, 300, 50);
        BotonConfirmarVehiculo.addActionListener((ActionEvent e)->{
            CuadroInformacionVehiculo.remove(VolverInformacionVehiculo);
            CuadroInformacionVehiculo.add(BotonVolverConfirmarVehiculo);
            
            CuadroConfirmarReserva.setVisible(false);
            MenuHacerReserva.remove(CuadroConfirmarReserva);
            MenuHacerReserva.add(CuadroInformacionVehiculo);
            CuadroInformacionVehiculo.setVisible(true);
        });
        
        JButton BotonConfirmarCliente = new JButton("Información del cliente");
        BotonConfirmarCliente.setBounds(200, 360, 300, 50);
        BotonConfirmarCliente.addActionListener((ActionEvent e)->{
            CuadroInformacionCliente.remove(VolverInformacionCliente);
            CuadroInformacionCliente.add(BotonVolverConfirmarCliente);
            
            CuadroConfirmarReserva.setVisible(false);
            MenuHacerReserva.remove(CuadroConfirmarReserva);
            MenuHacerReserva.add(CuadroInformacionCliente);
            CuadroInformacionCliente.setVisible(true);
        });
        
        JButton BotonInfVolverReserva = new JButton("volver");
        BotonInfVolverReserva.setBounds(5, 480, 100, 15);
        JButton BotonConfirmarReserva = new JButton("Confirmar Reserva");
        BotonConfirmarReserva.setBounds(595, 480, 100, 15);
        
        //---------------------------------------------------------------------------------------
        
        CuadroConfirmarReserva.add(TitleConfirmarReserva);
        CuadroConfirmarReserva.add(VolverConsultarReserva);
        CuadroConfirmarReserva.add(LabelConsultarNumero);
        CuadroConfirmarReserva.add(TextConfirmarNumero);
        CuadroConfirmarReserva.add(LabelConsultarRecogida);
        CuadroConfirmarReserva.add(TextConsultarRecogida);
        CuadroConfirmarReserva.add(LabelConsultarEntrega);
        CuadroConfirmarReserva.add(TextConsultarEntrega);
        CuadroConfirmarReserva.add(LabelConsultarInicio);
        CuadroConfirmarReserva.add(TextConsultarInicio);
        CuadroConfirmarReserva.add(LabelConsultarFinal);
        CuadroConfirmarReserva.add(TextConsultarFinal);
        CuadroConfirmarReserva.add(LabelConsultarReservacion);
        CuadroConfirmarReserva.add(TextConsultarReservacion);
        CuadroConfirmarReserva.add(LabelConsultarVehiculo);
        CuadroConfirmarReserva.add(TextConsultarVehiculo);
        CuadroConfirmarReserva.add(BotonConfirmarVehiculo);
        CuadroConfirmarReserva.add(LabelConsultarCliente);
        CuadroConfirmarReserva.add(TextConsultarCliente);
        CuadroConfirmarReserva.add(BotonConfirmarCliente);
        CuadroConfirmarReserva.add(VolverConsultarReserva);
        CuadroConfirmarReserva.add(BotonConfirmarReserva);
        CuadroConfirmarReserva.add(BotonInfVolverReserva);
        
        /*  
         *  ############################################################
         *  ###########---Componentes MenuHacerReserva---#############
         *  ############################################################
         */
        
        JPanel CuadroHacerReserva = new JPanel();
        JPanel CuadroInfClienteReserva = new JPanel();
        JPanel CuadroListCarrosReserva = new JPanel();
        CuadroHacerReserva.setBounds(70, 85, 935, 550);
        float[] verdecito = Color.RGBtoHSB(109, 255, 107, null);
        CuadroHacerReserva.setBackground(Color.getHSBColor(verdecito[0], verdecito[1], verdecito[2]));
        CuadroHacerReserva.setLayout(null);
        
        MenuHacerReserva.add(CuadroHacerReserva);
        
        JLabel TitleHacerReserva = new JLabel("Realizar Reserva");
        TitleHacerReserva.setBounds(400, 5, 500, 20);
        
        String mesint[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        
        JLabel LabelCedulaReserva = new JLabel("Cédula del cliente");
        LabelCedulaReserva.setBounds(5, 50, 400, 15);
        JTextField TextCedulaReserva = new JTextField();
        TextCedulaReserva.setBounds(150, 50, 230, 16);
        
        JLabel LabelReservaBuscarCliente = new JLabel();
        LabelReservaBuscarCliente.setBounds(150, 80, 230, 15);
        
        JLabel LabelReservaSEntrega = new JLabel("Sede de entrega");
        LabelReservaSEntrega.setBounds(390, 50, 400, 15);
        JTextField TextReservaSEntrega = new JTextField();
        TextReservaSEntrega.setBounds(505, 50, 150, 16);
        
        JLabel LabelReservaSDevuelve = new JLabel("Sede de devolución");
        LabelReservaSDevuelve.setBounds(390, 70, 400, 15);
        JTextField TextReservaSDevuelve = new JTextField();
        TextReservaSDevuelve.setBounds(505, 70, 150, 16);
        
        JLabel LabelReservaFEntrega = new JLabel("Fecha de entrega");
        LabelReservaFEntrega.setBounds(660, 50, 400, 15);
        JComboBox TextReservaFEntregaDia = new JComboBox(Dia);
        TextReservaFEntregaDia.setBounds(780, 50, 40, 16);
        JComboBox TextReservaFEntregaMes = new JComboBox(mesint);
        TextReservaFEntregaMes.setBounds(825, 50, 40, 16);
        JComboBox TextReservaFEntregaAno = new JComboBox(AnoExpiracion);
        TextReservaFEntregaAno.setBounds(870, 50, 60, 16);
        
        JLabel LabelReservaFDevuelve = new JLabel("Fecha de devolución");
        LabelReservaFDevuelve.setBounds(660, 70, 400, 15);
        JComboBox TextReservaFDevuelveDia = new JComboBox(Dia);
        TextReservaFDevuelveDia.setBounds(780, 70, 40, 16);
        JComboBox TextReservaFDevuelveMes = new JComboBox(mesint);
        TextReservaFDevuelveMes.setBounds(825, 70, 40, 16);
        JComboBox TextReservaFDevuelveAno = new JComboBox(AnoExpiracion);
        TextReservaFDevuelveAno.setBounds(870, 70, 60, 16);
        
        JLabel LabelReservaFiltrarTipo = new JLabel("Tipo");
        LabelReservaFiltrarTipo.setBounds(390, 120, 100, 15);        
        JRadioButton RadioReservaFiltrarAutomatico = new JRadioButton ("Automático");
        RadioReservaFiltrarAutomatico.setBounds(420, 120, 100, 15);
        JRadioButton RadioReservaFiltrarManual = new JRadioButton ("Manual");
        RadioReservaFiltrarManual.setBounds(420, 135, 100, 15);
        
        RadioReservaFiltrarAutomatico.addActionListener((ActionEvent e) -> {
            if (RadioReservaFiltrarManual.isSelected())
                RadioReservaFiltrarManual.setSelected(false);
        });
        RadioReservaFiltrarManual.addActionListener((ActionEvent e) -> {
            if (RadioReservaFiltrarAutomatico.isSelected())
                RadioReservaFiltrarAutomatico.setSelected(false);
        });
        
        JRadioButton RadioReservaFiltrarPrecio = new JRadioButton("Precio (menor a mayor)");
        RadioReservaFiltrarPrecio.setBounds(530, 120, 165, 15);
        
        JLabel LabelReservaFiltrarPasajeros = new JLabel("Cantidad de pasajeros");
        LabelReservaFiltrarPasajeros.setBounds(720, 120, 150, 15);
        JTextField TextReservaFiltrarPasajeros = new JTextField();
        TextReservaFiltrarPasajeros.setBounds(850, 120, 20, 16);
        
        JScrollPane ScrollEscogerVehiculo = new JScrollPane();
        ScrollEscogerVehiculo.setBounds(390, 155, 518, 300);
        
        JLabel LabelReservaServices = new JLabel("Servicios Adicionales");
        LabelReservaServices.setBounds(575, 460, 150, 15);
        
        JRadioButton RadioReservaOpcionalWifi = new JRadioButton("Wifi ilimitado: $15");
        RadioReservaOpcionalWifi.setBounds(390, 480, 250, 15);
        
        JRadioButton RadioReservaOpcionalAssist = new JRadioButton("Asistencia en carretera: $3.99");
        RadioReservaOpcionalAssist.setBounds(640, 480, 250, 15);
        
        JRadioButton RadioReservaOpcionalGPS = new JRadioButton("GPS: $13.99");
        RadioReservaOpcionalGPS.setBounds(390, 495, 250, 15);
        
        JRadioButton RadioReservaOpcionalAsiento = new JRadioButton("Asiento para niño: $6.99");
        RadioReservaOpcionalAsiento.setBounds(640, 495, 250, 15);
        
        JRadioButton RadioReservaOpcionalCobertura = new JRadioButton("Cobertura por daños a terceros: $12.99");
        RadioReservaOpcionalCobertura.setBounds(390, 510, 250, 15);
        
        //**********************************************************************
        
        CuadroInfClienteReserva.setBounds(5, 110, 380, 400);
        CuadroInfClienteReserva.setBackground(Color.getHSBColor(celestico[0], celestico[1], celestico[2]));
        CuadroInfClienteReserva.setLayout(null);
        
        JLabel LabelReservaClienteNombre = new JLabel("Nombre completo");
        LabelReservaClienteNombre.setBounds(5, 5, 400, 15);
        JTextField TextReservaClienteNombre = new JTextField();
        TextReservaClienteNombre.setBounds(145, 5, 230, 16);
        TextReservaClienteNombre.setEditable(false);
        
        JLabel LabelReservaClienteEmail = new JLabel("Correo electrónico");
        LabelReservaClienteEmail.setBounds(5, 25, 400, 15);
        JTextField TextReservaClienteEmail = new JTextField();
        TextReservaClienteEmail.setBounds(145, 25, 230, 16);
        TextReservaClienteEmail.setEditable(false);
        
        JLabel LabelReservaClienteTelefono = new JLabel("Numero de teléfono");
        LabelReservaClienteTelefono.setBounds(5, 45, 400, 15);
        JTextField TextReservaClienteTelefono = new JTextField();
        TextReservaClienteTelefono.setBounds(145, 45, 230, 16);
        TextReservaClienteTelefono.setEditable(false);
        
        JLabel LabelReservaClienteDireccion = new JLabel("Dirección exacta");
        LabelReservaClienteDireccion.setBounds(5, 65, 400, 15);
        JTextArea TextReservaClienteDireccion = new JTextArea();
        TextReservaClienteDireccion.setBounds(145, 65, 230, 70);
        TextReservaClienteDireccion.setEditable(false);
        
        JLabel LabelReservaClienteNumeroLic = new JLabel("Numero de licencia");
        LabelReservaClienteNumeroLic.setBounds(5, 140, 400, 15);
        JTextField TextReservaClienteNumeroLic = new JTextField();
        TextReservaClienteNumeroLic.setBounds(145, 140, 230, 16);
        TextReservaClienteNumeroLic.setEditable(false);
        
        JLabel LabelReservaClienteType = new JLabel("Tipo de licencia");
        LabelReservaClienteType.setBounds(5, 160, 400, 15);
        JTextField TextReservaClienteType = new JTextField();
        TextReservaClienteType.setBounds(145, 160, 230, 16);
        TextReservaClienteType.setEditable(false);
        
        JLabel LabelReservaClienteEmision = new JLabel("Fecha de emisión de la licencia");
        LabelReservaClienteEmision.setBounds(5, 180, 400, 15);
        JTextField TextReservaClienteEmision = new JTextField();
        TextReservaClienteEmision.setBounds(225, 180, 150, 16);
        TextReservaClienteEmision.setEditable(false);
        
        JLabel LabelReservaClienteExpiracion = new JLabel("Fecha de expiración de la licencia");
        LabelReservaClienteExpiracion.setBounds(5, 200, 400, 15);
        JTextField TextReservaClienteExpiracion = new JTextField();
        TextReservaClienteExpiracion.setBounds(225, 200, 150, 16);
        TextReservaClienteExpiracion.setEditable(false);
        
        JLabel LabelReservaClienteFoto = new JLabel("Fotografía de la licencia");
        LabelReservaClienteFoto.setBounds(120, 220, 400, 15);
        JLabel ImageReservaClienteFoto = new JLabel();
        ImageReservaClienteFoto.setBounds(80, 250, 240, 120);
        
        //----------------------------------------------------------------------
        
        CuadroInfClienteReserva.add(LabelReservaClienteNombre);
        CuadroInfClienteReserva.add(TextReservaClienteNombre);
        CuadroInfClienteReserva.add(LabelReservaClienteEmail);
        CuadroInfClienteReserva.add(TextReservaClienteEmail);
        CuadroInfClienteReserva.add(LabelReservaClienteTelefono);
        CuadroInfClienteReserva.add(TextReservaClienteTelefono);
        CuadroInfClienteReserva.add(LabelReservaClienteDireccion);
        CuadroInfClienteReserva.add(TextReservaClienteDireccion);
        CuadroInfClienteReserva.add(LabelReservaClienteNumeroLic);
        CuadroInfClienteReserva.add(TextReservaClienteNumeroLic);
        CuadroInfClienteReserva.add(LabelReservaClienteType);
        CuadroInfClienteReserva.add(TextReservaClienteType);
        CuadroInfClienteReserva.add(LabelReservaClienteEmision);
        CuadroInfClienteReserva.add(TextReservaClienteEmision);
        CuadroInfClienteReserva.add(LabelReservaClienteExpiracion);
        CuadroInfClienteReserva.add(TextReservaClienteExpiracion);
        CuadroInfClienteReserva.add(LabelReservaClienteFoto);
        CuadroInfClienteReserva.add(ImageReservaClienteFoto);
        
        //**********************************************************************
        
        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        
        final ArrayList<Vehiculo> CarroSeleccionado = new ArrayList<>();
        final ArrayList<Cliente> ClienteSeleccionado = new ArrayList<>();
        
        CuadroListCarrosReserva.setPreferredSize(new Dimension(500, 300));
        CuadroListCarrosReserva.setLayout(null);
        
        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

        JRadioButton ClienteBuscado = new JRadioButton();
        
        //-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/
        ///-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-
        //-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/
        
        JButton LabelReservaFiltrarB = new JButton("Filtrar Búsqueda");
        LabelReservaFiltrarB.setBounds(590, 100, 150, 15);
        LabelReservaFiltrarB.addActionListener((ActionEvent e) -> {
            ArrayList<Vehiculo> TodosLosVehiculos = adminOperador.getAdminVehiculo().getListaVehiculos();
            
            for (Vehiculo x : TodosLosVehiculos) {
                x.getCuadroVehiculo().setVisible(false);
                try{
                    CuadroListCarrosReserva.remove(x.getCuadroVehiculo());
                }
                catch(Exception f){}
            }
            
            ArrayList<Vehiculo> VehiculosFiltrados = new ArrayList<>();
            
            if (RadioReservaFiltrarAutomatico.isSelected()){
                for (Vehiculo x : TodosLosVehiculos)
                    if (x.getTipoTransmision()==transmision.automata)
                        VehiculosFiltrados.add(x);
            }
            else if (RadioReservaFiltrarManual.isSelected()){
                for (Vehiculo x : TodosLosVehiculos)
                    if (x.getTipoTransmision()==transmision.manual)
                        VehiculosFiltrados.add(x);
            }
            else{
                VehiculosFiltrados = TodosLosVehiculos;
            }
            
            TodosLosVehiculos = VehiculosFiltrados;
            ArrayList<Vehiculo> vehiculosFiltrados = new ArrayList<>();
            
            if (!TextReservaFiltrarPasajeros.getText().equals("")){
                for (Vehiculo x : TodosLosVehiculos)
                    if (x.getCapacidad()==Integer.parseInt(TextReservaFiltrarPasajeros.getText()))
                        vehiculosFiltrados.add(x);
            }
            else{
                vehiculosFiltrados = TodosLosVehiculos;
            }
            
            TodosLosVehiculos = vehiculosFiltrados;
            
            if (RadioReservaFiltrarPrecio.isSelected())
                for (int x = TodosLosVehiculos.size()-1; x >= 0; x--){
                    for (int y = TodosLosVehiculos.size()-1; y >= 0; y--){
                        if (y==TodosLosVehiculos.size()-1){}
                        else if(TodosLosVehiculos.get(y).getCostoAlquiler()>TodosLosVehiculos.get(y+1).getCostoAlquiler()){
                            Vehiculo temp = TodosLosVehiculos.get(y);
                            TodosLosVehiculos.set(y, TodosLosVehiculos.get(y+1));
                            TodosLosVehiculos.set(y+1, temp);
                        }
                    }
                }
            
            final ArrayList<Vehiculo> listaVehiculos = TodosLosVehiculos;
            for (int x = 0; x < listaVehiculos.size(); x++){
                final int SuperX = x;
                listaVehiculos.get(x).getCuadroVehiculo().setBounds(0, x*100, 500, 99);
                
                listaVehiculos.get(x).getSeleccionarVehiculo().addActionListener((ActionEvent E) -> {
                    CarroSeleccionado.clear();
                    CarroSeleccionado.add(listaVehiculos.get(SuperX));
                });
                
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
                
                listaVehiculos.get(x).getMasInformacionVehiculo().addActionListener((ActionEvent E) -> {
                    JButton BotonVolverInfVehiculoReserva = new JButton("Volver");
                    BotonVolverInfVehiculoReserva.setBounds(5, 480, 100, 15);
                    BotonVolverInfVehiculoReserva.addActionListener((ActionEvent ee) -> {
                        CuadroInformacionVehiculo.remove(BotonVolverInfVehiculoReserva);
                        CuadroInformacionVehiculo.add(VolverInformacionVehiculo);
                    
                        CuadroInformacionVehiculo.setVisible(false);
                        MenuHacerReserva.remove(CuadroInformacionVehiculo);
                        MenuHacerReserva.add(CuadroHacerReserva);
                        CuadroHacerReserva.setVisible(true);
                    
                        TextVehiculoInfPlaca.setText("");
                        TextVehiculoInfMarca.setText("");
                        TextVehiculoInfFabricacion.setText("");
                        TextVehiculoInfEstilo.setText("");
                        TextVehiculoInfColor.setText("");
                        TextVehiculoInfCapacidad.setText("");
                        TextVehiculoInfKilometraje.setText("");
                        TextVehiculoInfPuertas.setText("");
                        TextVehiculoInfVIN.setText("");
                        TextVehiculoInfMPG.setText("");
                        TextVehiculoInfSucursal.setText("");
                        TextVehiculoInfAlquiler.setText("");
                        TextVehiculoInfMaletas.setText("");
                        TextVehiculoInfTransmision.setText("");
                    });
                    CuadroInformacionVehiculo.remove(VolverInformacionVehiculo);
                    CuadroInformacionVehiculo.add(BotonVolverInfVehiculoReserva);
                    
                    TextVehiculoInfPlaca.setText(listaVehiculos.get(SuperX).getPlaca());
                    TextVehiculoInfMarca.setText(listaVehiculos.get(SuperX).getMarca());
                    TextVehiculoInfFabricacion.setText(String.valueOf(listaVehiculos.get(SuperX).getAnnoFabricacion()));
                    TextVehiculoInfEstilo.setText(listaVehiculos.get(SuperX).getEstilo().name());
                    TextVehiculoInfColor.setText(listaVehiculos.get(SuperX).getColor());
                    TextVehiculoInfCapacidad.setText(String.valueOf(listaVehiculos.get(SuperX).getCapacidad()));
                    TextVehiculoInfKilometraje.setText(String.valueOf(listaVehiculos.get(SuperX).getKilometraje()));
                    TextVehiculoInfPuertas.setText(String.valueOf(listaVehiculos.get(SuperX).getNumeroPuertas()));
                    TextVehiculoInfVIN.setText(listaVehiculos.get(SuperX).getNumeroVin());
                    TextVehiculoInfMPG.setText(String.valueOf(listaVehiculos.get(SuperX).getMpg()));
                    TextVehiculoInfSucursal.setText(listaVehiculos.get(SuperX).getSucursal());
                    TextVehiculoInfAlquiler.setText(String.valueOf(listaVehiculos.get(SuperX).getCostoAlquiler()));
                    TextVehiculoInfMaletas.setText(String.valueOf(listaVehiculos.get(SuperX).getCapacidadMaletas()));
                    TextVehiculoInfTransmision.setText(listaVehiculos.get(SuperX).getTipoTransmision().name());
                    
                    CuadroHacerReserva.setVisible(false);
                    MenuHacerReserva.remove(CuadroHacerReserva);
                    MenuHacerReserva.add(CuadroInformacionVehiculo);
                    CuadroInformacionVehiculo.setVisible(true);
                });
                
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
                
                //---------------------------------------------------------------------------------------
                listaVehiculos.get(x).getCuadroVehiculo().setVisible(true);
                CuadroListCarrosReserva.add(listaVehiculos.get(x).getCuadroVehiculo());
            }
            CuadroListCarrosReserva.setPreferredSize(new Dimension(500, TodosLosVehiculos.size()*100));
            CuadroListCarrosReserva.setLayout(null);
            CuadroListCarrosReserva.setBackground(Color.blue);
            ScrollEscogerVehiculo.setViewportView(CuadroListCarrosReserva);
        });
        
        //-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/
        ///-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-
        //-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/
        
        JButton BotonRealizarReserva = new JButton("Realizar reserva");
        BotonRealizarReserva.setBounds(780, 530, 150, 15);
        BotonRealizarReserva.addActionListener((ActionEvent e) -> {
            ServiciosOpcionales[] servicios = {ServiciosOpcionales.noservice, ServiciosOpcionales.noservice, ServiciosOpcionales.noservice,
                                               ServiciosOpcionales.noservice, ServiciosOpcionales.noservice};
            
            if(RadioReservaOpcionalWifi.isSelected())
                servicios[0] = ServiciosOpcionales.wifiIlimitado;
            if(RadioReservaOpcionalAssist.isSelected())
                servicios[1] = ServiciosOpcionales.asistenciaCarretera;
            if(RadioReservaOpcionalGPS.isSelected())
                servicios[2] = ServiciosOpcionales.GPS;
            if(RadioReservaOpcionalAsiento.isSelected())
                servicios[3] = ServiciosOpcionales.asientoNinos;
            if(RadioReservaOpcionalCobertura.isSelected())
                servicios[4] = ServiciosOpcionales.coberturaDanos;
            
            if(TextCedulaReserva.getText().equals("") || LabelReservaBuscarCliente.getText().equals("Cliente no encontrado!") || !ClienteBuscado.isSelected())
                JOptionPane.showMessageDialog(ventana, "No se ha seleccionado ningún cliente", "Error", JOptionPane.WARNING_MESSAGE);
            else if(TextReservaSEntrega.getText().equals("") || TextReservaSDevuelve.getText().equals(""))
                JOptionPane.showMessageDialog(ventana, "Debe ingresar una sede de entrega y de devolución", "Error", JOptionPane.WARNING_MESSAGE);
            else if(CarroSeleccionado.isEmpty())
                JOptionPane.showMessageDialog(ventana, "No se ha seleccionado ningún vehiculo", "Error", JOptionPane.WARNING_MESSAGE);
            else if(!adminOperador.comprobarFechasReserva(TextReservaFEntregaDia.getSelectedItem().toString(),
                                                          TextReservaFEntregaMes.getSelectedItem().toString(),
                                                          TextReservaFEntregaAno.getSelectedItem().toString(),
                                                          TextReservaFDevuelveDia.getSelectedItem().toString(),
                                                          TextReservaFDevuelveMes.getSelectedItem().toString(),
                                                          TextReservaFDevuelveAno.getSelectedItem().toString()))
                JOptionPane.showMessageDialog(ventana, "No se puede devolver el vehiculo antes de haber sido entregado...", "Error", JOptionPane.WARNING_MESSAGE);
            else{
                System.out.println(adminOperador.getNumReserva());
                BotonConfirmarReserva.addActionListener((ActionEvent ee) -> {
                    JOptionPane.showMessageDialog(ventana, "Reservación completada con éxito!", ":)", JOptionPane.INFORMATION_MESSAGE);
                    
                    adminOperador.agregarReserva(ClienteSeleccionado.get(0), CarroSeleccionado.get(0), TextReservaSEntrega.getText(),
                                                 TextReservaSDevuelve.getText(),
                                                 TextReservaFEntregaDia.getSelectedItem().toString(),
                                                 TextReservaFEntregaMes.getSelectedItem().toString(),
                                                 TextReservaFEntregaAno.getSelectedItem().toString(),
                                                 TextReservaFDevuelveDia.getSelectedItem().toString(),
                                                 TextReservaFDevuelveMes.getSelectedItem().toString(),
                                                 TextReservaFDevuelveAno.getSelectedItem().toString(), servicios);
                
                    TextConsultarRecogida.setText("");
                    TextConsultarEntrega.setText("");
                    TextConsultarInicio.setText("");
                    TextConsultarFinal.setText("");
                    TextConsultarVehiculo.setText("");
                    TextConsultarCliente.setText("");

                    TextlClienteInfNombre.setText("");
                    TextlClienteInfCedula.setText("");
                    TextlClienteInfEmail.setText("");
                    TextlClienteInfTelefono.setText("");
                    TextlClienteInfDireccion.setText("");
                    TextlClienteInfNumeroLic.setText("");
                    TextlClienteInfType.setText("");
                    TextlClienteInfEmision.setText("");
                    TextlClienteInfExpiracion.setText("");
                    ImageReservaClienteFoto.setIcon(new ImageIcon(""));

                    TextVehiculoInfPlaca.setText("");
                    TextVehiculoInfMarca.setText("");
                    TextVehiculoInfFabricacion.setText("");
                    TextVehiculoInfEstilo.setText("");
                    TextVehiculoInfColor.setText("");
                    TextVehiculoInfCapacidad.setText("");
                    TextVehiculoInfKilometraje.setText("");
                    TextVehiculoInfPuertas.setText("");
                    TextVehiculoInfVIN.setText("");
                    TextVehiculoInfMPG.setText("");
                    TextVehiculoInfSucursal.setText("");
                    TextVehiculoInfAlquiler.setText("");
                    TextVehiculoInfMaletas.setText("");
                    TextVehiculoInfTransmision.setText("");
                    
                    TextCedulaReserva.setText("");
                    TextReservaClienteNombre.setText("");
                    TextReservaClienteEmail.setText("");
                    TextReservaClienteTelefono.setText("");
                    TextReservaClienteDireccion.setText("");
                    TextReservaClienteNumeroLic.setText("");
                    TextReservaClienteType.setText("");
                    TextReservaClienteEmision.setText("");
                    TextReservaClienteExpiracion.setText("");
                    ImageReservaClienteFoto.setIcon(null);
                    
                    TextReservaSEntrega.setText("");
                    TextReservaSDevuelve.setText("");
                    
                    CuadroConfirmarReserva.setVisible(false);
                    MenuHacerReserva.remove(CuadroConfirmarReserva);
                    MenuHacerReserva.add(CuadroHacerReserva);
                    CuadroHacerReserva.setVisible(true);
                    
                    MenuHacerReserva.setVisible(false);
                    ventana.remove(MenuHacerReserva);
                    ventana.add(MenuPrincipal);
                    MenuPrincipal.setVisible(true);
                });
                
                BotonInfVolverReserva.addActionListener((ActionEvent ee) -> {
                
                    TextConsultarRecogida.setText("");
                    TextConsultarEntrega.setText("");
                    TextConsultarInicio.setText("");
                    TextConsultarFinal.setText("");
                    TextConsultarVehiculo.setText("");
                    TextConsultarCliente.setText("");

                    TextlClienteInfNombre.setText("");
                    TextlClienteInfCedula.setText("");
                    TextlClienteInfEmail.setText("");
                    TextlClienteInfTelefono.setText("");
                    TextlClienteInfDireccion.setText("");
                    TextlClienteInfNumeroLic.setText("");
                    TextlClienteInfType.setText("");
                    TextlClienteInfEmision.setText("");
                    TextlClienteInfExpiracion.setText("");
                    ImageReservaClienteFoto.setIcon(new ImageIcon(""));

                    LabelReservaBuscarCliente.setText("");
                    TextVehiculoInfPlaca.setText("");
                    TextVehiculoInfMarca.setText("");
                    TextVehiculoInfFabricacion.setText("");
                    TextVehiculoInfEstilo.setText("");
                    TextVehiculoInfColor.setText("");
                    TextVehiculoInfCapacidad.setText("");
                    TextVehiculoInfKilometraje.setText("");
                    TextVehiculoInfPuertas.setText("");
                    TextVehiculoInfVIN.setText("");
                    TextVehiculoInfMPG.setText("");
                    TextVehiculoInfSucursal.setText("");
                    TextVehiculoInfAlquiler.setText("");
                    TextVehiculoInfMaletas.setText("");
                    TextVehiculoInfTransmision.setText("");
                    
                    CuadroConfirmarReserva.setVisible(false);
                    MenuHacerReserva.remove(CuadroConfirmarReserva);
                    MenuHacerReserva.add(CuadroHacerReserva);
                    CuadroHacerReserva.setVisible(true);
                });
                
                TextConfirmarNumero.setText(String.valueOf(adminOperador.getNumReserva()));
                TextConsultarRecogida.setText(TextReservaSEntrega.getText());
                TextConsultarEntrega.setText(TextReservaSDevuelve.getText());
                TextConsultarInicio.setText(TextReservaFEntregaDia.getSelectedItem().toString() + "/" +
                                            TextReservaFEntregaMes.getSelectedItem().toString() + "/" +
                                            TextReservaFEntregaAno.getSelectedItem().toString());
                TextConsultarFinal.setText(TextReservaFDevuelveDia.getSelectedItem().toString() + "/" +
                                           TextReservaFDevuelveMes.getSelectedItem().toString() + "/" +
                                           TextReservaFDevuelveAno.getSelectedItem().toString());
                TextConsultarVehiculo.setText(CarroSeleccionado.get(0).getMarca() + " - " + CarroSeleccionado.get(0).getPlaca());
                TextConsultarCliente.setText(ClienteSeleccionado.get(0).getNombre());
                
                TextlClienteInfNombre.setText(ClienteSeleccionado.get(0).getNombre());
                TextlClienteInfCedula.setText(ClienteSeleccionado.get(0).getCedula());
                TextlClienteInfEmail.setText(ClienteSeleccionado.get(0).getCorreoElectronico());
                TextlClienteInfTelefono.setText(ClienteSeleccionado.get(0).getTelefono());
                TextlClienteInfDireccion.setText(ClienteSeleccionado.get(0).getDireccion());
                TextlClienteInfNumeroLic.setText(ClienteSeleccionado.get(0).getLicencia().getNumeroLicencia());
                TextlClienteInfType.setText(ClienteSeleccionado.get(0).getLicencia().getTipoLicencia());
                Calendar emision = ClienteSeleccionado.get(0).getLicencia().getFechaEmision();
                TextlClienteInfEmision.setText(emision.get(Calendar.DAY_OF_MONTH) + "/" + emision.get(Calendar.MONTH) + "/" + emision.get(Calendar.YEAR));
                Calendar expiracion = ClienteSeleccionado.get(0).getLicencia().getFeachaExpiracion();
                TextlClienteInfExpiracion.setText(expiracion.get(Calendar.DAY_OF_MONTH) + "/" + expiracion.get(Calendar.MONTH) + "/" + expiracion.get(Calendar.YEAR));
                ImageReservaClienteFoto.setIcon(new ImageIcon(ClienteSeleccionado.get(0).getLicencia().getImagenLicencia()));
                
                TextVehiculoInfPlaca.setText(CarroSeleccionado.get(0).getPlaca());
                TextVehiculoInfMarca.setText(CarroSeleccionado.get(0).getMarca());
                TextVehiculoInfFabricacion.setText(String.valueOf(CarroSeleccionado.get(0).getAnnoFabricacion()));
                TextVehiculoInfEstilo.setText(CarroSeleccionado.get(0).getEstilo().name());
                TextVehiculoInfColor.setText(CarroSeleccionado.get(0).getColor());
                TextVehiculoInfCapacidad.setText(String.valueOf(CarroSeleccionado.get(0).getCapacidad()));
                TextVehiculoInfKilometraje.setText(String.valueOf(CarroSeleccionado.get(0).getKilometraje()));
                TextVehiculoInfPuertas.setText(String.valueOf(CarroSeleccionado.get(0).getNumeroPuertas()));
                TextVehiculoInfVIN.setText(CarroSeleccionado.get(0).getNumeroVin());
                TextVehiculoInfMPG.setText(String.valueOf(CarroSeleccionado.get(0).getMpg()));
                TextVehiculoInfSucursal.setText(CarroSeleccionado.get(0).getSucursal());
                TextVehiculoInfAlquiler.setText(String.valueOf(CarroSeleccionado.get(0).getCostoAlquiler()));
                TextVehiculoInfMaletas.setText(String.valueOf(CarroSeleccionado.get(0).getCapacidadMaletas()));
                TextVehiculoInfTransmision.setText(CarroSeleccionado.get(0).getTipoTransmision().name());
                
                
                CuadroHacerReserva.setVisible(false);
                MenuHacerReserva.remove(CuadroHacerReserva);
                MenuHacerReserva.add(CuadroConfirmarReserva);
                CuadroConfirmarReserva.setVisible(true);
            }
        });
        
        JButton BotonReservaBuscarCliente = new JButton("Buscar");
        BotonReservaBuscarCliente.setBounds(5, 70, 100, 30);
        BotonReservaBuscarCliente.addActionListener((ActionEvent e) -> {
            if (!ClienteBuscado.isSelected())
                ClienteBuscado.setSelected(true);
            if (adminOperador.buscarCliente(TextCedulaReserva.getText())==null){
                LabelReservaBuscarCliente.setText("Cliente no encontrado!");
                TextReservaClienteNombre.setText("");
                TextReservaClienteEmail.setText("");
                TextReservaClienteTelefono.setText("");
                TextReservaClienteDireccion.setText("");
                TextReservaClienteNumeroLic.setText("");
                TextReservaClienteType.setText("");
                TextReservaClienteEmision.setText("");
                TextReservaClienteExpiracion.setText("");
                ImageReservaClienteFoto.setIcon(null);
                
                ClienteSeleccionado.clear();
            }
            else{
                Cliente encontrado = adminOperador.buscarCliente(TextCedulaReserva.getText());
                LabelReservaBuscarCliente.setText("");
                TextReservaClienteNombre.setText(encontrado.getNombre());
                TextReservaClienteEmail.setText(encontrado.getCorreoElectronico());
                TextReservaClienteTelefono.setText(encontrado.getTelefono());
                TextReservaClienteDireccion.setText(encontrado.getDireccion());
                TextReservaClienteNumeroLic.setText(encontrado.getLicencia().getNumeroLicencia());
                TextReservaClienteType.setText(encontrado.getLicencia().getTipoLicencia());
                Calendar emision = encontrado.getLicencia().getFechaEmision();
                TextReservaClienteEmision.setText(emision.get(Calendar.DAY_OF_MONTH) + "/" + emision.get(Calendar.MONTH) + "/" + emision.get(Calendar.YEAR));
                Calendar expiracion = encontrado.getLicencia().getFeachaExpiracion();
                TextReservaClienteExpiracion.setText(expiracion.get(Calendar.DAY_OF_MONTH) + "/" + expiracion.get(Calendar.MONTH) + "/" + expiracion.get(Calendar.YEAR));
                ImageReservaClienteFoto.setIcon(new ImageIcon(encontrado.getLicencia().getImagenLicencia()));
                
                ClienteSeleccionado.clear();
                ClienteSeleccionado.add(encontrado);
            }
        });
        
        JButton VolverHacerReserva = new JButton("Volver");
        VolverHacerReserva.setBounds(5, 530, 100, 15);
        VolverHacerReserva.addActionListener((ActionEvent e) -> {
            TextCedulaReserva.setText("");
            TextReservaClienteNombre.setText("");
            TextReservaClienteEmail.setText("");
            TextReservaClienteTelefono.setText("");
            TextReservaClienteDireccion.setText("");
            TextReservaClienteNumeroLic.setText("");
            TextReservaClienteType.setText("");
            TextReservaClienteEmision.setText("");
            TextReservaClienteExpiracion.setText("");
            ImageReservaClienteFoto.setIcon(null);
            
            TextReservaSEntrega.setText("");
            TextReservaSDevuelve.setText("");
                    
            MenuHacerReserva.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuHacerReserva);
        });
        
        //----------------------------------------------------------------------
        
        CuadroHacerReserva.add(ScrollEscogerVehiculo);
        CuadroHacerReserva.add(TitleHacerReserva);
        CuadroHacerReserva.add(VolverHacerReserva);
        CuadroHacerReserva.add(BotonRealizarReserva);
        CuadroHacerReserva.add(LabelCedulaReserva);
        CuadroHacerReserva.add(TextCedulaReserva);
        CuadroHacerReserva.add(BotonReservaBuscarCliente);
        CuadroHacerReserva.add(LabelReservaBuscarCliente);
        CuadroHacerReserva.add(CuadroInfClienteReserva);
        CuadroHacerReserva.add(LabelReservaSEntrega);
        CuadroHacerReserva.add(TextReservaSEntrega);
        CuadroHacerReserva.add(LabelReservaSDevuelve);
        CuadroHacerReserva.add(TextReservaSDevuelve);
        CuadroHacerReserva.add(LabelReservaFEntrega);
        CuadroHacerReserva.add(TextReservaFEntregaDia);
        CuadroHacerReserva.add(TextReservaFEntregaMes);
        CuadroHacerReserva.add(TextReservaFEntregaAno);
        CuadroHacerReserva.add(LabelReservaFDevuelve);
        CuadroHacerReserva.add(TextReservaFDevuelveDia);
        CuadroHacerReserva.add(TextReservaFDevuelveMes);
        CuadroHacerReserva.add(TextReservaFDevuelveAno);
        CuadroHacerReserva.add(LabelReservaFiltrarB);
        CuadroHacerReserva.add(LabelReservaFiltrarTipo);
        CuadroHacerReserva.add(RadioReservaFiltrarAutomatico);
        CuadroHacerReserva.add(RadioReservaFiltrarManual);
        CuadroHacerReserva.add(RadioReservaFiltrarPrecio);
        CuadroHacerReserva.add(LabelReservaFiltrarPasajeros);
        CuadroHacerReserva.add(TextReservaFiltrarPasajeros);
        CuadroHacerReserva.add(LabelReservaServices);
        CuadroHacerReserva.add(RadioReservaOpcionalWifi);
        CuadroHacerReserva.add(RadioReservaOpcionalAssist);
        CuadroHacerReserva.add(RadioReservaOpcionalGPS);
        CuadroHacerReserva.add(RadioReservaOpcionalAsiento);
        CuadroHacerReserva.add(RadioReservaOpcionalCobertura);
        
        /*  
         *  ############################################################
         *  ###########---Componentes MenuRegistrarAdmin---#############
         *  ############################################################
         */
        
        JPanel CuadroRegistrarAdmin = new JPanel();
        CuadroRegistrarAdmin.setBounds(290, 110, 500, 500);
        float[] rosa = Color.RGBtoHSB(255, 107, 248, null);
        CuadroRegistrarAdmin.setBackground(Color.getHSBColor(rosa[0], rosa[1], rosa[2]));
        CuadroRegistrarAdmin.setLayout(null);
        
        MenuRegistrarAdmin.add(CuadroRegistrarAdmin);
        
        JLabel TitleRegistrarAdmin = new JLabel("Registrar Usuario con rol de Servicio al cliente");
        TitleRegistrarAdmin.setBounds(100, 5, 500, 20);
        
        JLabel LabelAdminNombre = new JLabel("Nombre Completo");
        LabelAdminNombre.setBounds(5, 50, 400, 15);
        JTextField TextAdminNombre = new JTextField();
        TextAdminNombre.setBounds(150, 50, 330, 16);
        
        JLabel LabelAdminCedula = new JLabel("Cédula");
        LabelAdminCedula.setBounds(5, 70, 400, 15);
        JTextField TextAdminCedula = new JTextField();
        TextAdminCedula.setBounds(150, 70, 330, 16);
        
        JLabel LabelAdminEmail = new JLabel("Correo electrónico");
        LabelAdminEmail.setBounds(5, 90, 400, 15);
        JTextField TextAdminEmail = new JTextField();
        TextAdminEmail.setBounds(150, 90, 330, 16);
        
        JLabel LabelAdminTelefono = new JLabel("Número de teléfono");
        LabelAdminTelefono.setBounds(5, 110, 400, 15);
        JTextField TextAdminTelefono = new JTextField();
        TextAdminTelefono.setBounds(150, 110, 330, 16);
        
        JLabel LabelAdminDireccion = new JLabel("Dirección exacta");
        LabelAdminDireccion.setBounds(5, 130, 400, 15);
        JTextArea TextAdminDireccion = new JTextArea();
        TextAdminDireccion.setBounds(150, 130, 330, 96);
        
        JLabel LabelAdminFoto = new JLabel("Fotografía del usuario");
        LabelAdminFoto.setBounds(5, 240, 400, 15);
        JButton BuscarAdminFoto = new JButton("Buscar...");
        BuscarAdminFoto.setBounds(380, 240, 100, 15);
        JTextField RutaAdminFoto = new JTextField();
        RutaAdminFoto.setBounds(150, 240, 220, 15);
        JLabel ImagenAdminFoto = new JLabel();
        ImagenAdminFoto.setBounds(150, 330, 200, 150);
        BuscarAdminFoto.addActionListener((ActionEvent f) ->{
            JFileChooser BuscarFoto = new JFileChooser();
            int returnValue = BuscarFoto.showOpenDialog(null);
            if(returnValue == JFileChooser.APPROVE_OPTION){
            File Foto = BuscarFoto.getSelectedFile();
            final String temp = Foto.getPath();
            FotoDir[0]=temp;
            RutaAdminFoto.setText(temp);
            ImagenAdminFoto.setIcon(new ImageIcon(Foto.getPath()));
            }
        });
        RutaAdminFoto.setEditable(false);
        
        JTextComponent[] textosRegistrarAdmin = {TextAdminNombre, TextAdminCedula, TextAdminEmail,
                                                 TextAdminTelefono, TextAdminDireccion, RutaAdminFoto};
        
        JButton BotonRegistrarAdmin = new JButton("Registrar");
        BotonRegistrarAdmin.setBounds(395, 480, 100, 15);
        // Linea que agregar en el menu final
        BotonRegistrarAdmin.addActionListener((ActionEvent e) -> {
            
            if(!"".equals(TextAdminNombre.getText())&&!"".equals(TextAdminCedula.getText())&&!"".equals(TextAdminEmail.getText())&&
                !"".equals(TextAdminTelefono.getText())&&!"".equals(TextAdminDireccion.getText())
                ){
                
                String mensaje=adminOperador.agregarEmpleado(TextAdminEmail.getText(), TextAdminCedula.getText(), TextAdminNombre.getText(), 
                        TextAdminDireccion.getText(), FotoDir[0], TextAdminTelefono.getText());
                JOptionPane.showMessageDialog(null, mensaje, "Informativo", JOptionPane.INFORMATION_MESSAGE);
                ImagenAdminFoto.setIcon(null);
                clearText(textosRegistrarAdmin);
                MenuRegistrarAdmin.setVisible(false);
                ventana.add(MenuPrincipal);
                MenuPrincipal.setVisible(true);
                ventana.remove(MenuRegistrarAdmin);
            }else{
                
                System.out.println(adminOperador.buscarEmpleado(TextAdminCedula.getText()));
                JOptionPane.showMessageDialog(null, "Faltan llenar espacio", "Advertencia", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton VolverRegistrarAdmin = new JButton("Volver");
        VolverRegistrarAdmin.setBounds(5, 480, 100, 15);
        VolverRegistrarAdmin.addActionListener((ActionEvent e) -> {
            ImagenAdminFoto.setIcon(null);
            clearText(textosRegistrarAdmin);
            MenuRegistrarAdmin.setVisible(false);
            ventana.add(MenuPrincipal);
            MenuPrincipal.setVisible(true);
            ventana.remove(MenuRegistrarAdmin);
        });
        
        //----------------------------------------------------------------------
        
        CuadroRegistrarAdmin.add(BotonRegistrarAdmin);
        CuadroRegistrarAdmin.add(LabelAdminNombre);
        CuadroRegistrarAdmin.add(TextAdminNombre);
        CuadroRegistrarAdmin.add(LabelAdminCedula);
        CuadroRegistrarAdmin.add(TextAdminCedula);
        CuadroRegistrarAdmin.add(LabelAdminDireccion);
        CuadroRegistrarAdmin.add(TextAdminDireccion);
        CuadroRegistrarAdmin.add(LabelAdminEmail);
        CuadroRegistrarAdmin.add(TextAdminEmail);
        CuadroRegistrarAdmin.add(LabelAdminTelefono);
        CuadroRegistrarAdmin.add(TextAdminTelefono);
        CuadroRegistrarAdmin.add(LabelAdminFoto);
        CuadroRegistrarAdmin.add(BuscarAdminFoto);
        CuadroRegistrarAdmin.add(RutaAdminFoto);
        CuadroRegistrarAdmin.add(TitleRegistrarAdmin);
        CuadroRegistrarAdmin.add(VolverRegistrarAdmin);
        CuadroRegistrarAdmin.add(ImagenAdminFoto);
        
        /*
         *  #############################################
         *  #############################################
         *  ######---Componentes Iniciar sesión---#######
         *  #############################################
         *  #############################################
         */
        
        JPanel PanelIniciarSesion = new JPanel(); //400, 100  415-250-415  310-100-310
        PanelIniciarSesion.setLayout(null);
        PanelIniciarSesion.setBackground(Color.LIGHT_GRAY);
        
        JLabel LabelIniciarSesion = new JLabel("Iniciar sesión");
        LabelIniciarSesion.setBounds(490, 300, 200, 15);
        
        JLabel LabelIniciarSesionUsuario = new JLabel("Nombre de Usuario");
        LabelIniciarSesionUsuario.setBounds(400, 330, 200, 15);
        JTextField TextIniciarSesionUsuario = new JTextField();
        TextIniciarSesionUsuario.setBounds(520, 330, 130, 16);
        
        JLabel LabelIniciarSesionContraseña = new JLabel("Contraseña");
        LabelIniciarSesionContraseña.setBounds(400, 360, 200, 15);
        JPasswordField TextIniciarSesionContraseña = new JPasswordField();
        TextIniciarSesionContraseña.setBounds(520, 360, 130, 16);
        
        JButton BotonIniciarSesion = new JButton("Iniciar Sesion");
        BotonIniciarSesion.setBounds(460, 400, 130, 16);
        BotonIniciarSesion.addActionListener((ActionEvent e) -> {
            if(adminOperador.buscarEmpleadoPorNombre(TextIniciarSesionUsuario.getText())==null)
                JOptionPane.showMessageDialog(ventana, "Usuario no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
            else if(!adminOperador.hacerLogin(TextIniciarSesionUsuario.getText(), TextIniciarSesionContraseña.getText()))
                JOptionPane.showMessageDialog(ventana, "Contraseña Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
            else{
                PanelIniciarSesion.setVisible(false);
                ventana.remove(PanelIniciarSesion);
                ventana.add(MenuPrincipal);
            }
        });
        
        //----------------------------------------------------------------------
        
        PanelIniciarSesion.add(LabelIniciarSesion);
        PanelIniciarSesion.add(LabelIniciarSesionUsuario);
        PanelIniciarSesion.add(TextIniciarSesionUsuario);
        PanelIniciarSesion.add(LabelIniciarSesionContraseña);
        PanelIniciarSesion.add(TextIniciarSesionContraseña);
        PanelIniciarSesion.add(BotonIniciarSesion);
        
        //Instrucción final...
        
        ventana.add(PanelIniciarSesion);
        ventana.setSize(1080,720); 
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        Window();
    }
    
}
