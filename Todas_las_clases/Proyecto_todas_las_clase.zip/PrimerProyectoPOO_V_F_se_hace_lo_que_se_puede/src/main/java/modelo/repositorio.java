/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Calendar;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Random;
/**
 *
 * @author josue
 */
public class repositorio {
    //funcion que envia mensajes a un correo.
    
    public static boolean enviarConGmail(String destinatario,String nombre,String clave){
        Properties prop= System.getProperties();
        String password="Proyectos2020";
        String remitente="proyectospoo2020@gmail.com";
        
        
        prop.put("mail.smtp.host", "smtp.gamil.com");
        prop.put("mail.smtp.user",remitente);
        prop.put("mail.smtp.password", password);
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.port", "587");
        
        Session session=Session.getDefaultInstance(prop);
        MimeMessage message = new MimeMessage(session);
        try{
        
            message.setFrom(new InternetAddress(remitente));
            message.addRecipients(Message.RecipientType.TO, destinatario);
            message.setSubject("Nombre de usuario y clave para logearse");
            message.setText("Bienvenido a la empresa<br>"+"Su nombre de usuario es: <b>"+nombre+"</b><br>"
                            +"Su contraseña es: <b>"+clave+"</b>"
                               ,"ISO-8859-1","html");
            Transport t=session.getTransport("smtp");
            t.connect("smtp.gmail.com",remitente,password);
            t.sendMessage(message, message.getAllRecipients());
            t.close();
            
            return true;
        }catch(MessagingException me){
            return false;
        }
        
    }
    
    public static String crearClave(String nombre){
        Random alea = new Random();
        String letrasEspeciales="!#$@";
        String numeros="123456789";
        int indice=0;
        String clave = "";
        
        for (int i = 0; i < 4; i++) {
            indice=alea.nextInt(nombre.length());
            if(i%2==0){
                clave=clave+nombre.substring(indice, indice+1).toUpperCase();
            }else{
                clave=clave+nombre.substring(indice, indice+1).toLowerCase();
            }
            
            
        }
        for (int i = 0; i < 4; i++) {
            if(i==3){
                indice=alea.nextInt(letrasEspeciales.length());
                clave=clave+letrasEspeciales.substring(indice, indice+1);
            }else{
                indice=alea.nextInt(numeros.length());
                clave=clave+numeros.substring(indice, indice+1);
            }
        }
        
        
        return clave;
    }
    
    public static  String formatoFecha(Calendar fecha){
        return fecha.get(Calendar.DATE)+"/"+(fecha.get(Calendar.MONTH)+1)+"/"+fecha.get(Calendar.YEAR);
    }
    
    //metodo que no esta en el modelo
    public static boolean validarCorreo(String correoElectronico){
        try{
        int posArroba = correoElectronico.indexOf("@");
        int posPunto = correoElectronico.indexOf(".");
        String organizacion=correoElectronico.substring(posArroba+1, posPunto);
        String tipo =correoElectronico.substring(posPunto+1);
        int contador = organizacion.length();
        int i = 0;
        
        if (!tipo.equals("com")){
            return false;
        }
        while (i<contador){
        
            if(organizacion.equals("gmail") || organizacion.equals("hotmail") ){
                return true;
                
            }
            i++;
        }}catch(Exception e){
            return false;
        }
       return false;
        
        
    }
    
}
