/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import modelo.Empresa;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author h
 */
public class AdministradorEmpresas {
    ArrayList<Empresa> listaEmpresas; 

    public ArrayList<Empresa> getListaEmpresas() {
        return listaEmpresas;
    }

    public void setListaEmpresas(ArrayList<Empresa> listaEmpresas) {
        this.listaEmpresas = listaEmpresas;
    }
    
    public void agregarEmpresa(Empresa nuevaEmpresa){
        this.listaEmpresas.add(nuevaEmpresa);
    }
    
    public Empresa crearEmpresa(String nombre, String razonSocial, String numeroCedula, String telefono, String direccion){
        Empresa nuevaEmpresa = new Empresa(nombre, razonSocial, numeroCedula, telefono, direccion);
        agregarEmpresa(nuevaEmpresa);
        
        return nuevaEmpresa;
    }
    
        public void eliminarEmpresas(String cedula){
            for(int i = 0; i < listaEmpresas.size(); i++){
                 if(listaEmpresas.get(i).getNumeroCedula() == cedula){
                    listaEmpresas.remove(i);
                }
            }
        System.out.println("No se encontró ningún servicio");
    }
}
