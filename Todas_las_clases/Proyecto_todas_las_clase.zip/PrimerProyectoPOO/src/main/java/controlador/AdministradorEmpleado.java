/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import modelo.Empleado;
import modelo.repositorio;

/**
 *
 * @author josue
 */
public class AdministradorEmpleado {
   private ArrayList<Empleado> empleados= new ArrayList<Empleado>();

    public AdministradorEmpleado() {
        empleados.add(new Empleado("Admin", "1234", true, "Admin@gmail.com"));
    }
    
   
    public boolean crearEmpleado(String correoElectronico, String cedula,String nomEmpleado,String direccion
                                    ,String foto, String tel){
    
        //meterle comprobacion de correo

        if (buscarEmpleado(cedula)==null){
            if(repositorio.validarCorreo(correoElectronico)){
                int indice = correoElectronico.indexOf("@");
                String nombre= correoElectronico.substring(0, indice);
                String contrasena=repositorio.crearClave(nombre);
            
                //repositorio.enviarConGmail(correoElectronico, nombre, contrasena);
                Empleado nuevo =new Empleado(nombre, contrasena, correoElectronico, cedula, 
                                            nomEmpleado, direccion, foto, tel);
                empleados.add(nuevo);
        
                return true;
        }}
                                    
        return false;
    } 
    
    public Empleado buscarEmpleado(String cedula){
        for (int i = 0; i < empleados.size(); i++) {
            Empleado actEmpleado = empleados.get(i);
            
            if(actEmpleado.getCedula().equals(cedula)){
                
                return actEmpleado;
            }
            
        }
        return null;
    }
    
    public Empleado buscarEmpleadoPorNombre(String nombre){
        for (int i = 0; i < empleados.size(); i++) {
            Empleado actEmpleado = empleados.get(i);
            
            if(actEmpleado.getNombre().equals(nombre)){
                
                return actEmpleado;
            }
            
        }
        return null;
    }
   
    //listo
    public boolean comprobarClave(String nombre,String clave){
        Empleado  actEmpleado= buscarEmpleadoPorNombre(nombre);
        
        if(actEmpleado!=null){
            return actEmpleado.getClave().equals(clave);
        }
        return false;
    }
    
    //listo
    public String getEmpleado(String cedula){
        Empleado actEmpleado=buscarEmpleado(cedula);
        
        if(actEmpleado!=null){
            return actEmpleado.toString();
        }
            return "No existe el empleado  buscado";
    }
    
    

    @Override
    public String toString() {
        return "AdministradorEmpleado{" + "empleados=" + empleados + '}';
    }
    
    
    
    
}
