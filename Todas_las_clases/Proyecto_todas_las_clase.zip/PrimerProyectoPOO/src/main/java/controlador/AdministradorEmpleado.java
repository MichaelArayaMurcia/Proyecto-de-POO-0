/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import modelo.Empleado;
import modelo.repositorio;

/**
 *
 * @author josue
 */
public class AdministradorEmpleado {
   private ArrayList<Empleado> empleados= new ArrayList<Empleado>();

    public AdministradorEmpleado() {
        empleados.add(new Empleado("Admin", "1234", true, "Admin@gmail.com"));
    }
   
    public boolean crearEmpleado(String correoElectronico, boolean rol){
    
        //meterle comprobacion de correo
        if(validarCorreo(correoElectronico)){
            int indice = correoElectronico.indexOf("@");
            String nombre= correoElectronico.substring(0, indice);
            String contrasena=repositorio.crearClave(nombre);
            
            //repositorio.enviarConGmail(correoElectronico, nombre, contrasena);
            Empleado nuevo = new Empleado(nombre,contrasena, rol,correoElectronico);
            empleados.add(nuevo);
        
            return true;
        }
        return false;
    } 
    
    public Empleado buscarEmpleado(String nombre){
        for (int i = 0; i < empleados.size(); i++) {
            Empleado actEmpleado = empleados.get(i);
            
            if(actEmpleado.getNombre().equalsIgnoreCase(nombre)){
                
                return actEmpleado;
            }
            
        }
        return null;
    }
   
    public boolean comprobarClave(String nombre,String clave){
        Empleado  actEmpleado= buscarEmpleado(nombre);
        
        if(actEmpleado!=null){
            return actEmpleado.getClave().equals(clave);
        }
        return false;
    }
    
    //metodo que no esta en el modelo
    public String getEmpleado(String nombre){
        Empleado actEmpleado=buscarEmpleado(nombre);
        
        if(actEmpleado!=null){
            return actEmpleado.toString();
        }
            return "No existe el empleado  buscado";
    }
    
    //metodo que no esta en el modelo
    public boolean validarCorreo(String correoElectronico){
    
        int posArroba = correoElectronico.indexOf("@");
        int posPunto = correoElectronico.indexOf(".");
        String organizacion=correoElectronico.substring(posArroba+1, posPunto);
        String tipo =correoElectronico.substring(posPunto+1);
        int contador = organizacion.length();
        int i = 0;
        
        if (!tipo.equals("com")){
            return false;
        }
        while (i<contador){
        
            if(organizacion.equals("gmail") || organizacion.equals("hotmail") ){
                return true;
                
            }
            i++;
        }
        return false;
        
        
    }

    @Override
    public String toString() {
        return "AdministradorEmpleado{" + "empleados=" + empleados + '}';
    }
    
    
    
    
}
