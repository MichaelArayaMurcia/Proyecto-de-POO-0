/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.Calendar;
import modelo.Cliente;
import modelo.Empleado;
import modelo.Reservas;
import modelo.repositorio;


/**
 *
 * @author josue
 */

public class AdminOperador {
    private String operador;
    private AdministradorEmpleado adminEmpleados= new AdministradorEmpleado();
    private ArrayList<Cliente> clientes= new ArrayList<Cliente>();
    private AdministradorVehiculos adminVehiculo=new AdministradorVehiculos();
    private ArrayList<Reservas> reservas= new ArrayList<Reservas>();

    public AdminOperador() {
    }
    
    public boolean hacerLogin(String nombre,String clave){
        if(adminEmpleados.buscarEmpleadoPorNombre(nombre)!=null){
            
            operador=adminEmpleados.buscarEmpleadoPorNombre(nombre).getNombreEmpleado();
            return adminEmpleados.comprobarClave(nombre, clave);
        }
        return false;
        
        
    }
    
    public Cliente buscarCliente(String cedula){
        
        for (int i = 0; i < clientes.size(); i++) {
            Cliente actCliente = clientes.get(i);
            if(actCliente.getCedula().equals(cedula)){
                return actCliente;
            }
            
        }
        return null;
    }
    
    //metodo que no esta en el modelo
    public String agregarEmpleado(String correoElectronico, String cedula,String nomEmpleado,String direccion
                                    ,String foto, String tel){
        if(adminEmpleados.crearEmpleado(correoElectronico, cedula, nomEmpleado, direccion,foto, tel)){
            return "Empleado agregado con exito";
        }else{
            return "Fallo en la creacion del empleado";
        }
    }
    
    //metodo que no esta en el modelo
    public String buscarEmpleado(String cedula){
        return adminEmpleados.getEmpleado(cedula);
    }
    
    //metodo que no esta en el modelo
    public boolean agregarCliente(String nombre,String cedula, String direccion, String correoElectronico,
                                    String tel, String foto,String numLicencia,Calendar emision,Calendar expira
                                    , String tipo,String imgLicencia){
        if (buscarCliente(cedula)==null){
            if (repositorio.validarCorreo(correoElectronico)){
                Cliente nuevoEmpleado= new Cliente(nombre, cedula, direccion, correoElectronico, tel, foto);
                clientes.add(nuevoEmpleado);
                nuevoEmpleado.crearLicencia(numLicencia, emision, expira, tipo, imgLicencia);
                return true;
            }
        }
        return false;
             
    }
    
    //metodo que no esta en el modelo
    public Reservas buscarReserva(int numReserva){
        for (int i = 0; i < reservas.size(); i++) {
            Reservas actReserva = reservas.get(i);
            if(actReserva.getNumReserva()==numReserva){
                return actReserva;
            }
        }
        return null;
    }
    
    //metodo que no esta en el modelo
    public String[] listaNumreservas(){
        String[] lista= {};
        for (int i = 0; i < reservas.size(); i++) {
            Reservas actReserva = reservas.get(i);
            lista[i]=String.valueOf(actReserva.getNumReserva());
            
        }
        return lista;
    }
    
    //metodo que no esta en el modelo
    public ArrayList consultaReserva(int numReserva){
        Reservas actReserva=buscarReserva(numReserva);
        ArrayList lista = new ArrayList();
       if(actReserva!=null){
           lista.add(actReserva);
           lista.add(actReserva.getNombreCliente());
           lista.add(actReserva.getVehiculo());
           return lista;
       }
       return lista;
        
    }
    
    //metodo que no esta en el modelo
    public String getCliente(String cedula){
        Cliente actCliente=buscarCliente(cedula);
        if(actCliente!=null){
            return actCliente.toString();
        }
        return "No existe el cliente con esa cedula";
    }
    
    @Override
    public String toString() {
        return "AdminOperador{" + "operador=" + operador + ", adminEmpleados=" + adminEmpleados 
                + ", clientes=" + clientes + ", adminVehiculo=" + adminVehiculo + '}';
    }
    
    

    

    
    
    
}
