/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

/**
 *
 * @author h
 */
import modelo.Servicio;
import java.util.ArrayList;
import java.util.Scanner;  // Import the Scanner class

public class AdministradorServicios {
    ArrayList<Servicio> listaServicios;  

    public AdministradorServicios(ArrayList<Servicio> listaServicio) {
        this.listaServicios = listaServicio;
    }

    public ArrayList<Servicio> getListaServicio() {
        return listaServicios;
    }

    public void setListaServicio(ArrayList<Servicio> listaServicio) {
        this.listaServicios = listaServicio;
    }
    
    public Servicio buscarServicio(String ID){
        for(int i = 0; i < listaServicios.size(); i++){
            if(listaServicios.get(i).getId().equals(ID)){
                return listaServicios.get(i);
            }
        }
        System.out.println("No se encontró ningún servicio");
        return null;
    }
    
    public Servicio crearServicio(){
        System.out.println("Inserte el ID del servicio");
        boolean disponible = true;
        String nuevoID = "";
        Scanner objetoLector = new Scanner(System.in);
        nuevoID = objetoLector.nextLine();
        
        for(int i = 0; i < listaServicios.size(); i++){
            if(listaServicios.get(i).getId().equals(nuevoID)){
                System.out.println("No se permiten servicios con el mismo ID");
                disponible = false;
            }
        }
        
        if(disponible){
            System.out.println("Inserte el monto pagado");
            Double montoPagado;
            montoPagado = objetoLector.nextDouble();
            
            System.out.println("Inserte la actividad realizada");
            String actividadRealizada;
            actividadRealizada = objetoLector.nextLine();
            
            System.out.println("Inserte el tipo de servicio");
            String tipoServicio;
            tipoServicio = objetoLector.nextLine();
            
            System.out.println("Inserte la empresa");
            String empresa;
            empresa = objetoLector.nextLine();
            
            Servicio nuevoServicio = new Servicio(nuevoID, montoPagado, actividadRealizada, tipoServicio, empresa);
            
            return nuevoServicio;
        }       
        
        return null;
    }
    
    public void asignarVehiculo(){
    
    }
    
    public void eliminarServicio(String ID){
        for(int i = 0; i < listaServicios.size(); i++){
            if(listaServicios.get(i).getId().equals(ID)){
                listaServicios.remove(i);
            }
        }
        System.out.println("No se encontró ningún servicio");
    }
    
}


