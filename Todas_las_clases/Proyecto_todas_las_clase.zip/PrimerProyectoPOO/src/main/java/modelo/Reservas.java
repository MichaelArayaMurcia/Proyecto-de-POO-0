/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author josue
 */
public class Reservas {
    private String sedeRecogida;
    private String sedeEntrega;
    private Calendar fechaInicio;
    private Calendar fechaFinal;    
    private ArrayList<ServiciosOpcionales> ServiciosExtra;

    public Reservas(String sedeRecogida, String sedeEntrega, Calendar fechaInicio, Calendar fechaFinal) {
        this.sedeRecogida = sedeRecogida;
        this.sedeEntrega = sedeEntrega;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
    }

    public String getSedeRecogida() {
        return sedeRecogida;
    }

    public void setSedeRecogida(String sedeRecogida) {
        this.sedeRecogida = sedeRecogida;
    }

    public String getSedeEntrega() {
        return sedeEntrega;
    }

    public void setSedeEntrega(String sedeEntrega) {
        this.sedeEntrega = sedeEntrega;
    }

    public Calendar getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Calendar fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Calendar getFechaFinal() {
        return fechaFinal;
    }

    public ArrayList<ServiciosOpcionales> listaServiciosExtra() {
        return ServiciosExtra;
    }

    public void agregarServiciosExtra(ServiciosOpcionales ServiciosExtra) {
        this.ServiciosExtra.add(ServiciosExtra);
    }
    
    public void agregarServiciosExtra(ArrayList<ServiciosOpcionales> ServiciosExtra) {
        this.ServiciosExtra=ServiciosExtra;
    }
    
    public void setFechaFinal(Calendar fechaFinal) {
        this.fechaFinal = fechaFinal;
    }
    
    
}
