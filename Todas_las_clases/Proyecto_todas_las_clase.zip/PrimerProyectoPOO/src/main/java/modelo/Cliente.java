/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Calendar;

/**
 *
 * @author josue
 */
public class Cliente {
    private String nombre;
    private String cedula;
    private String direccion;
    private String correoElectronico;
    private String telefono;
    private String fotografia;
    private Licencia licencia;//esta es el obejeto licencia no es un atributo directo

    public Cliente(String nombre, String cedula, String direccion, String correoElectronico, String telefono, String fotografia) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
        this.telefono = telefono;
        this.fotografia = fotografia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFotografia() {
        return fotografia;
    }

    public void setFotografia(String fotografia) {
        this.fotografia = fotografia;
    }
    
    public boolean crearLicencia(String numLicencia,Calendar fecEmision,Calendar fecExpira, String tipo,String imagen){
        licencia = new Licencia(numLicencia,fecEmision,fecExpira,tipo,imagen);
        return true;
    }

    public Licencia getLicencia() {
        return licencia;
    }
    

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", cedula=" + cedula + ", direccion=" + direccion + 
                ", correoElectronico=" + correoElectronico + ", telefono=" + telefono + 
                ", fotografia=" + fotografia + ", licencia=" + licencia + '}';
    }
    


    
}
