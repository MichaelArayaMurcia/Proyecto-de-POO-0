/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author josue
 */
public class Empleado {
    private String nombre;
    private String clave;
    private boolean esAdmin;
    private String correoElectronico;
    private String cedula;
    private String nombreEmpleado;
    private String direccion;
    private String foto;
    private String telefono;

    public Empleado(String nombre, String clave, boolean esAdmin, String correoElectronico) {
        this.nombre = nombre;
        this.clave = clave;
        this.esAdmin = esAdmin;
        this.correoElectronico = correoElectronico;
    }

    

    public Empleado(String nombre, String clave, String correoElectronico, String cedula, String nombreEmpleado, String direccion, String foto, String telefono) {
        this.nombre = nombre;
        this.clave = clave;
        this.correoElectronico = correoElectronico;
        this.cedula = cedula;
        this.nombreEmpleado = nombreEmpleado;
        this.direccion = direccion;
        this.foto = foto;
        this.telefono = telefono;
        this.esAdmin=false;
    }

    
    
    
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public boolean isEsAdmin() {
        return esAdmin;
    }

    public void setEsAdmin(boolean esAdmin) {
        this.esAdmin = esAdmin;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", clave=" + clave + ", esAdmin=" + esAdmin + ", correoElectronico=" + 
                correoElectronico + ", cedula=" + cedula + ", nombreEmpleado=" + nombreEmpleado + ", direccion=" + 
                direccion + ", foto=" + foto + ", telefono=" + telefono + '}';
    }
    
    

       
    
}
