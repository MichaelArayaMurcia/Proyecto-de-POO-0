/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author h
 */
public class Empresa {
    String razonSocial = "";
    String numeroCedula = "";
    String telefono = "";
    String direccion = "";

    public Empresa(String razonSocial, String numeroCedula, String telefono, String direccion) {
        this.razonSocial = razonSocial;
        this.numeroCedula = numeroCedula;
        this.telefono = telefono;
        this.direccion = direccion;
    }   

    @Override
    public String toString() {
        return "Empresa{" + "razonSocial=" + razonSocial + ", numeroCedula=" + numeroCedula + ", telefono=" + telefono + ", direccion=" + direccion + '}';
    }

    
    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getNumeroCedula() {
        return numeroCedula;
    }

    public void setNumeroCedula(String numeroCedula) {
        this.numeroCedula = numeroCedula;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
}
