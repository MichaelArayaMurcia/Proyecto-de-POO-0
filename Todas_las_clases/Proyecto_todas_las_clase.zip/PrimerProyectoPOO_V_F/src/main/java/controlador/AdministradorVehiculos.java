/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.Vehiculo;
import modelo.estilo;
import modelo.transmision;
import modelo.estado;

/**
 *
 * @author araya
 */
public class AdministradorVehiculos {
    private ArrayList<Vehiculo> listaVehiculos;

    public AdministradorVehiculos() {
        listaVehiculos = new ArrayList<>();
        listaVehiculos.add(new Vehiculo("000-000", 2002, estilo.intermedio, "Azul", "Toyota", 4, 0.0, 4, "Vin-00", 15.3, "Guacamaya", 15, 2, transmision.automata,""));
        listaVehiculos.add(new Vehiculo("000-001", 1953, estilo.MiniVan, "Rojo", "Hyundai", 7, 0.0, 6, "Vin-01", 14.3, "Guacamaya", 22, 1, transmision.manual,""));
        listaVehiculos.add(new Vehiculo("000-002", 2009, estilo.SUV, "Verde", "Subaru", 4, 0.0, 4, "Vin-02", 17.3, "Guacamaya", 13, 1, transmision.automata,""));
        listaVehiculos.add(new Vehiculo("000-003", 1999, estilo.compacto, "Negro", "Ferrari", 4, 0.0, 2, "Vin-03", 10.3, "Guacamaya", 19, 3, transmision.manual,""));
        listaVehiculos.add(new Vehiculo("000-004", 2018, estilo.convertible_economico, "Violeta", "Hyundai", 4, 0.0, 4, "Vin-04", 20, "Guacamaya", 30, 1, transmision.automata,""));
        listaVehiculos.add(new Vehiculo("000-005", 2010, estilo.pickup, "Blanco", "Chevrolet", 4, 0.0, 4, "Vin-05", 22.3, "Guacamaya", 10, 1, transmision.manual,""));
        listaVehiculos.add(new Vehiculo("000-006", 2000, estilo.intermedio, "Gris", "Toyota", 7, 0.0, 6, "Vin-06", 19.9, "Guacamaya", 12, 2, transmision.automata,""));
        listaVehiculos.add(new Vehiculo("000-007", 1978, estilo.compacto, "Azul", "Subaru", 4, 0.0, 4, "Vin-07", 14.8, "Guacamaya", 18, 1, transmision.manual,""));
        listaVehiculos.add(new Vehiculo("000-008", 2013, estilo.MiniVan, "Celeste", "Toyota", 4, 0.0, 2, "Vin-08", 21.2, "Guacamaya", 19, 2, transmision.automata,""));
        listaVehiculos.add(new Vehiculo("000-009", 1989, estilo.convertible_economico, "amarillo", "Hyundai", 4, 0.0, 4, "Vin-09", 16.3, "Guacamaya", 9, 1, transmision.manual,""));
    }
    
    public void registrarVehiculo(String placa, int annoFabricacion, estilo Estilo, String color, String marca, int capacidad, double kilometraje, int numeroPuertas, String numeroVin, double mpg, String sucursal, double costoAlquiler, int capacidadMaletas, transmision tipoTransmision, String foto){
        if(listaVehiculos.size()==0){
            Vehiculo nuevoVehiculo = new Vehiculo(placa, annoFabricacion, Estilo, color, marca, capacidad, kilometraje, numeroPuertas, numeroVin, mpg, sucursal, costoAlquiler, capacidadMaletas, tipoTransmision, foto);
            this.listaVehiculos.add(nuevoVehiculo);
        }
        else{
            boolean noExiste = true;
            for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca()==placa){
                System.out.println("El vehiculo ya existe en la lista.");
                noExiste = false;
                break;
            }
            }
            if(noExiste){
                Vehiculo nuevoVehiculo = new Vehiculo(placa, annoFabricacion, Estilo, color, marca, capacidad, kilometraje, numeroPuertas, numeroVin, mpg, sucursal, costoAlquiler, capacidadMaletas, tipoTransmision, foto);
                this.listaVehiculos.add(nuevoVehiculo);
            }
        }
    }
    
    public Vehiculo buscarVehiculo(String placa){
        for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca().equals(placa)){
                return unVehiculo;
            }
        }
        return null;
    }
    
    public void cambiarEstadoVehiculo(){
        System.out.println("Ingrese la placa del carro al que desea cambiarle el estado: ");
        String placa;
        Scanner objetoLector = new Scanner(System.in);
        placa = objetoLector.nextLine();
        System.out.println("Ingrese el nuevo estado del Vehiculo: ");
        String Estado = objetoLector.nextLine();
        estado nuevoEstado = estado.Activo;
        if(Estado == estado.Mantenimiento.name()){
            nuevoEstado = estado.Mantenimiento;
        }
        else if(Estado == estado.Inactivo.name()){
            nuevoEstado = estado.Inactivo;
        }
        for (int i = 0; i < listaVehiculos.size(); i++) {
            Vehiculo unVehiculo = listaVehiculos.get(i);
            if(unVehiculo.getPlaca()==placa){
                unVehiculo.setEstado(nuevoEstado);
            }
        }
    }
    
    //public void cambiarPropiedadVehiculo(String placa){}

    public ArrayList<Vehiculo> getListaVehiculos() {
        return listaVehiculos;
    }

    @Override
    public String toString() {
        return "AdministradorVehiculos{" + "listaVehiculos=" + listaVehiculos + '}';
    }
    
}
